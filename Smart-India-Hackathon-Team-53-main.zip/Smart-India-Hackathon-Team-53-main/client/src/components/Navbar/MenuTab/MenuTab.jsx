import React from "react";

import {
  Link, useLocation
} from "react-router-dom";

import './MenuTab.css'

const MenuTab = ({tabsInfo}) => {
  const currentPathname = useLocation().pathname

  const MenuTabOption = ({ tab }) => {
    // console.log(currentPathname)
    return (
      <Link to = {tab.link}>
        <div className = { currentPathname === tab.link ? "navMenuItem isActive" : "navMenuItem"}>
          <div className = "icon">
            <tab.icon style = {{ color: "#111" }} />
          </div>
          <h5>{tab.name}</h5>
        </div>
      </Link>
    )
  }
  
  return (
    <div className = "menuTab">
      <div className = "navMenu">
        { tabsInfo.map((tab, index) => <MenuTabOption tab={tab} key={index} />) }
      </div>
    </div>
  );
};

export default MenuTab;