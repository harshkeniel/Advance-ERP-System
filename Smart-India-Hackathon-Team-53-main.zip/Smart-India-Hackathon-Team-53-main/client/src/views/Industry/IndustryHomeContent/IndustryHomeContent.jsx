import React from 'react'

import './IndustryHomeContent.css'

const IndustryHomeContent = () => {
    return (
        <div className="industryHomeContent homeContent">
            Industry Home Content
        </div>
    )
}

export default IndustryHomeContent