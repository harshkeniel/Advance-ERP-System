import React from 'react'

const Chats = () => {
  return (
    <div className="card">
        Chats Tab
    </div>
  )
}

export default Chats