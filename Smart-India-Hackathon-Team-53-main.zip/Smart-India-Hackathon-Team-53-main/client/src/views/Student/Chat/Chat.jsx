import React from 'react'

import './Chat.css'

const Chat = () => {
  return (
    <div className="Chat">
        <div className="chatBody">
          Chat
        </div>
    </div>
  )
}

export default Chat