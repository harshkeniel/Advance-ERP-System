const EducationData = [

    {
        collegeName: 'Thakur College of Engineering and Technology',
        studyField: 'Computer Engineering',
        degree: 'B.E',
        grade: 85.85,
        startYear: 2019,
        endYear: 2023
    },

    {
        collegeName: 'S.S. & L.S. Patkar College of Arts and Science',
        studyField: '',
        degree: 'Higher Secondary Education',
        grade: 84.15,
        startYear: 2017,
        endYear: 2019
    },

    {
        collegeName: 'S.S. & L.S. Patkar College of Arts and Science',
        studyField: '',
        degree: 'Secondary School Certificate',
        grade: 93,
        startYear: 2007,
        endYear: 2017
    }
]

export default EducationData;