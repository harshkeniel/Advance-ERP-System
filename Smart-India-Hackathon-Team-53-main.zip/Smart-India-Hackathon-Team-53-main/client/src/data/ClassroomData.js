import SiddheshPic from '../assets/images/siddheshProfilePhoto.png'
import NinadPic from '../assets/images/ninadProfilePhoto.jpg'
import RahulPic from '../assets/images/rahulProfilePhoto.jpg'
import HarshPic from '../assets/images/harshProfilePhoto.jpg'
import VishalPic from '../assets/images/vishalProfilePhoto.jpg'

const classroomData = [
    {
      code: "1",
      name: "Project Based Learning",
      facultyName: "Veena Kulkarni",
      facultyImg: SiddheshPic,
      assignments: [
        {
          assignmentName: "Project 1",
          assignmentDate: "20-08-2022",

        },
        {
          assignmentName: "Project 2",
          assignmentDate: "19-08-2022",

        },
        {
          assignmentName: "Project 3",
          assignmentDate: "18-08-2022",

        },
        {
          assignmentName: "Project 4",
          assignmentDate: "17-08-2022",

        },
        {
          assignmentName: "Project 5",
          assignmentDate: "16-08-2022",

        }
      ]
    },
    {
      code: "2",
      name: "Research Based Learning",
      facultyName: "Manish Rana",
      facultyImg: NinadPic,
      assignments: [
        {
          assignmentName: "Project 2",
          assignmentDate: "19-08-2022",

        }
      ]  
    },
    {
      code: "3",
      name: "Professional Skills",
      facultyName: "Jesal Varolia",
      facultyImg: RahulPic,
      assignments: [
        {
          assignmentName: "Project 3",
          assignmentDate: "20-08-2022",

        }
      ]
    },
    {
      code: "4",
      name: "Employability Skill Development",
      facultyName: "Dr Zahir Aalam",
      facultyImg: HarshPic,
      assignments: [
        {
          assignmentName: "Project 4",
          assignmentDate: "20-08-2022",

        }
      ]
    },
    {
      code: "5",
      name: "Internet Programming",
      facultyName: "Foram Shah",
      facultyImg: SiddheshPic,
      assignments: [
        {
          assignmentName: "Project 5",
          assignmentDate: "20-08-2022",

        }
      ]
    },
    {
      code: "6",
      name: "Project Based Learning",
      facultyName: "Dr Manish Rana",
      facultyImg: VishalPic,
      assignments: [
        {
          assignmentName: "Project 6",
          assignmentDate: "20-08-2022",

        }
      ]
    },
    {
      code: "7",
      name: "Project Based Learning",
      facultyName: "Dr Manish Rana",
      facultyImg: RahulPic,
      assignments: [
        {
          assignmentName: "Project 7",
          assignmentDate: "20-08-2022",

        }
      ]
    }
]

export default classroomData