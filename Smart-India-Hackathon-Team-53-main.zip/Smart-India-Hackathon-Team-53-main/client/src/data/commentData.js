import authorOneIcon from '../assets/images/siddheshProfilePhoto.png';
import authorTwoIcon from '../assets/images/harshProfilePhoto.jpg';
import authorThreeIcon from '../assets/images/rahulProfilePhoto.jpg';
import subAuthorOneIcon from '../assets/images/ninadProfilePhoto.jpg';

const commentData = [

    {
        commentAuthor: 'Siddhesh Mane',
        latestUpdated: '14th August, 2022 22:30',
        description: "Excellent Project !! What Tech Stack did you use for this project ?",
        commentAuthorPic: authorOneIcon,
        commentVotes: 93,
        commentSubAuthors: [

            {
                commentAuthor: 'Ninad Patil',
                latestUpdated: '15th August, 2022 22:30',
                description: "I used React for the WebApp and some Python and Computer Vision too.",
                commentAuthorPic: subAuthorOneIcon,
                commentVotes: 2
            }
        ]
    },

    {
        commentAuthor: 'Harsh Mishra',
        latestUpdated: '16th August, 2022 22:30',
        commentAuthorPic: authorTwoIcon,
        description: "Woah !! Cool Project buddy",
        commentVotes: 45,
        commentSubAuthors: []
    },

    {
        commentAuthor: 'Rahul Prajapati',
        latestUpdated: '16th August, 2022 22:30',
        commentAuthorPic: authorThreeIcon,
        description: "Woah !! Cool Project buddy",
        commentVotes: 45,
        commentSubAuthors: []
    }
]

export default commentData;