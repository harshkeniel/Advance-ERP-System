const data = [
  {
    id : "1",
    text : "Build Wireframes",
    status : "backlog"
  },
  // {
  //   id : "2",
  //   text : "Review Wireframes",
  //   status : "backlog"
  // },
  {
    id : "3",
    text : "Write HTML & CSS",
    status : "backlog"
  },
  // {
  //   id : "4",
  //   text : "Design Database",
  //   status : "backlog"
  // },
  // {
  //   id : "5",
  //   text : "Setup Backend REST API",
  //   status : "backlog"
  // },
  {
    id : "6",
    text : "Integrate all API calls",
    status : "backlog"
  },
]

export default data