const SkillsData = [

    {
        name: 'HTML',
        color: 'lightblue',
    },

    {
        name: 'CSS',
        color: 'lightcoral',
    },

    {
        name: 'Javascript',
        color: 'lightgreen',
    },

    {
        name: 'React JS',
        color: 'lightgrey',
    },

    {
        name: 'Node JS',
        color: 'pink'
    }

];

export default SkillsData;