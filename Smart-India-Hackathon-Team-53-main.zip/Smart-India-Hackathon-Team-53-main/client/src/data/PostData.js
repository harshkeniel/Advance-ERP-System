import postImageOne from '../assets/images/ninadProject.png'
import postImageTwo from '../assets/images/siddheshProject.jpg'
import postImageThree from '../assets/images/rahulProject.jpg'
import postImageFour from '../assets/images/harshProject.png'
import postImageFive from '../assets/images/vishalProject.png'

import NinadPic from '../assets/images/ninadProfilePhoto.jpg'
import SiddheshPic from '../assets/images/siddheshProfilePhoto.png'
import RahulPic from '../assets/images/rahulProfilePhoto.jpg'
import HarshPic from '../assets/images/harshProfilePhoto.jpg'
import VishalPic from '../assets/images/vishalProfilePhoto.jpg'

const PostData = [
  
  {
    name: "Ninad Patil",
    domainDetails: {
        domainName: "Web development",
        color: "lightblue"
    },
    title: "I Developed a Covid Dashboard for the VCET Hackathon Competition 2021",
    img: postImageOne,
    avatar: NinadPic,
    clapCount: "32",
    commentCount: 54,
    isBookmarked : true
  },

  {
    name: "Siddhesh Mane",
    domainDetails: {
      domainName: "Web development",
      color: "lightblue"
  },
    title: "I developed a Video-Chat Conferencing Web app with WebRTC and socket.io",
    img: postImageTwo,
    avatar: SiddheshPic,
    clapCount: "45",
    commentCount: 67,
    isBookmarked : true
  },

  {
    name: "Rahul Prajapati",
    domainDetails: {
      domainName: "Web development",
      color: "lightblue"
  },
    title: "I developed a Sorting Visualizer for visualizing Sorting Algorithms",
    img: postImageThree,
    avatar: RahulPic,
    clapCount: "16",
    commentCount: 36,
    isBookmarked : false
  },

  {
    name: "Harsh Mishra",
    domainDetails: {
        domainName: "Machine Learning",
        color: "lightcoral"
    },
    title: "I built a Data science salary job estimation application using Streamlit",
    img: postImageFour,
    avatar: HarshPic,
    clapCount: "16",
    commentCount: 36,
    isBookmarked : false
  },

  {
    name: "Vishal Pandey",
    domainDetails: {
      domainName: "Web development",
      color: "lightblue"
    },
    title: "I built a ERP System for College Management system",
    img: postImageFive,
    avatar: VishalPic,
    clapCount: "16",
    commentCount: 36,
    isBookmarked : false
  },

];

export default PostData;