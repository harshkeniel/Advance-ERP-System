const UpdatesData = [

    {
        title: 'Planning task complete',
        posted: '5 days',
        readers: '64'
    },

    {
        title: 'Auto-magic task list adding is live!',
        posted: '5 days',
        readers: '64'
    },

    {
        title: 'Task list has been launched!',
        posted: '5 days',
        readers: '64'
    },

    {
        title: 'Url-ifying feed links',
        posted: '5 days',
        readers: '64'
    },

    {
        title: 'Analytics is a go!',
        posted: '5 days',
        readers: '64'
    }

];

export default UpdatesData;