const CertificationData = [

    {
        title: 'Programming for Everybody (Getting Started with Python) - Coursera',
        certificateLink: 'https://github.com/Siddhesh25082001',
    },

    {
        title: 'Python Data Structures - Coursera',
        certificateLink: 'https://github.com/Siddhesh25082001',
    },

    {
        title: 'Programming in C - Nptel',
        certificateLink: 'https://github.com/Siddhesh25082001',
    },

]

export default CertificationData;