const AchievementData = [

    {
        title: 'Smart India Hackathon Finalist 2022',
        issuer: 'Coursera',
        issueDate: 'August 2022',
        description: 'Finalist of Smart India Hackathon'
    },

    {
        title: 'JP Morgan Code for Good Hackathon 2022 Participant',
        issuer: 'Coursera',
        issueDate: 'August 2022',
        description: 'JP Morgan Code for Good 2022 Participant (Top 1.6K out of 52K Participants)'
    },

    {
        title: 'Winner of TCET Hackanova 2022',
        issuer: 'Coursera',
        issueDate: 'August 2022',
        description: 'Claimed the Winners Position out of 26 Participating groups'
    },
]

export default AchievementData;