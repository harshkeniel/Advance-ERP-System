'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('project_tasks', {
      task_id:{
        type:DataTypes.UUID,
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4
      },
      project_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      assigned_to:{
        type:DataTypes.UUID,
        allowNull:false
      },
      name:{
        type:DataTypes.STRING,
        allowNull:false
      },
      description:{
        type:DataTypes.STRING,
        allowNull:true
      },
      status:{
        type:DataTypes.STRING,
        defaultValue:'To-do'
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('project_tasks');
  }
};