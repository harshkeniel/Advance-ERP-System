'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('user_certifications', {
      certification_id:{
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        type:DataTypes.UUID
      },
      title:{
        allowNull:false,
        type:DataTypes.STRING
      },
      skills:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.STRING)
      },
      description:{
        allowNull:true,
        type:DataTypes.STRING(1000)
      },
      issue_date:{
        type:DataTypes.DATEONLY,
        allowNull:true
      },
      link:{
        type:DataTypes.STRING
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('user_certifications');
  }
};