'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('domain_boards', {
      board_id:{
        type:DataTypes.UUID,
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4
      },
      board_name:{
        type:DataTypes.STRING,
        allowNull:false
      },
      board_color:{
        type:DataTypes.STRING,
        allowNull:false
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('domain_boards');
  }
};