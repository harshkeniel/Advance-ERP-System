'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('comments', {
      comment_id:{
        primaryKey:true,
        allowNull:false,
        type:DataTypes.UUID,
        defaultValue:DataTypes.UUIDV4
      },
      type:{
        allowNull:false,
        type:DataTypes.STRING
      },
      type_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      user_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      comment_description:{
        allowNull:false,
        type:DataTypes.STRING(1000)
      },
      votes:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('comments');
  }
};