'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('user_pors', {
      por_id:{
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        type:DataTypes.UUID
      },
      title:{
        allowNull:true,
        type:DataTypes.STRING
      },
      skills:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.STRING)
      },
      position:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.STRING)
      },
      start:{
        type:DataTypes.DATEONLY
      },
      end:{
        type:DataTypes.DATEONLY
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('user_pors');
  }
};