'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('comment_replies', {
      reply_id:{
        primaryKey:true,
        allowNull:false,
        type:DataTypes.UUID,
        defaultValue:DataTypes.UUIDV4
      },
      comment_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      user_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      comment_description:{
        type:DataTypes.STRING(1000),
        allowNull:false
      },
      votes:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('comment_replies');
  }
};