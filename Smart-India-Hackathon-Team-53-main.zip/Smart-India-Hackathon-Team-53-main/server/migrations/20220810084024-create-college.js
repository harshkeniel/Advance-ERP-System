'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('colleges', {
      college_id: {
        allowNull:false,
        type:DataTypes.UUID,
        primaryKey:true,
        defaultValue:DataTypes.UUID
      },
      college_name:{
        allowNull:false,
        type:DataTypes.STRING
      },
      university_name:{
        allowNull:true,
        type:DataTypes.STRING
      },
      college_logo:{
        allowNull : true,
        type : DataTypes.STRING
      },
      college_banner:{
        allowNull : true,
        type : DataTypes.STRING
      },
      college_code:{
        allowNull:true,
        type:DataTypes.STRING
      },
      state:{
        allowNull:true,
        type:DataTypes.STRING
      },
      city:{
        allowNull:true,
        type:DataTypes.STRING
      },
      pinned_projects:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.UUID)
      },
      pinned_students:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.UUID)
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('colleges');
  }
};