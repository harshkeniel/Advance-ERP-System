'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('projects', {
      project_id:{
        type:DataTypes.UUID,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        allowNull:false
      },
      user_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      title:{
        type:DataTypes.STRING,
        allowNull:false
      },
      description:{
        type:DataTypes.STRING(1000),
        allowNull:true
      },
      domain:{
        type:DataTypes.ARRAY(DataTypes.STRING),
        allowNull:true
      },
      tags:{
        type:DataTypes.ARRAY(DataTypes.STRING),
        allowNull:true
      },
      tech_stack:{
        type:DataTypes.ARRAY(DataTypes.STRING),
        allowNull:true
      },
      problem_it_solves:{
        type:DataTypes.STRING(1000),
        allowNull:true
      },
      challenges_faced:{
        type:DataTypes.STRING(1000)
      },
      visibility:{
        type:DataTypes.STRING,
        defaultValue:'private'
      },
      visits:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('projects');
  }
};