'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('project_media', {
      media_id:{
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4,
        type:DataTypes.UUID
      },
      project_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      media_url:{
        type:DataTypes.STRING,
        allowNull:false
      },
      file_name:{
        type:DataTypes.STRING,
        allowNull:false
      },
      file_type:{
        type:DataTypes.STRING,
        allowNull:false
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('project_media');
  }
};