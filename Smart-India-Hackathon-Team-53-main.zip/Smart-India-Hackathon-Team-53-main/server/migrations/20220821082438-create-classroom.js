'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('classrooms', {
      classroom_id:{
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4,
        type:DataTypes.UUID
      },
      faculty_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      classroom_name:{
        type:DataTypes.STRING,
        allowNull:false
      },
      classroom_code:{
        type:DataTypes.STRING,
        allowNull:false,
        unique:true
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('classrooms');
  }
};