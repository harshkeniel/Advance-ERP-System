'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('user_achievements', {
      achievement_id:{
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        type:DataTypes.UUID
      },
      title:{
        allowNull:false,
        type:DataTypes.STRING
      },
      issuer:{
        allowNull:true,
        type:DataTypes.STRING
      },
      issue_date:{
        type:DataTypes.DATEONLY
      },
      description:{
        type:DataTypes.STRING(1000)
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('user_achievements');
  }
};