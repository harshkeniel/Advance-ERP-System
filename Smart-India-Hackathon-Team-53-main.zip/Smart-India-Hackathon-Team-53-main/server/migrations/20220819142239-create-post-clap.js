'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('post_claps', {
      post_id:{
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID
      },
      user_id:{
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('post_claps');
  }
};