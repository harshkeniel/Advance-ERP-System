'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('teams', {
      team_id:{
        type:DataTypes.UUID,
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4
      },
      leader_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      project_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      team_name:{
        type:DataTypes.STRING,
        allowNull:true
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('teams');
  }
};