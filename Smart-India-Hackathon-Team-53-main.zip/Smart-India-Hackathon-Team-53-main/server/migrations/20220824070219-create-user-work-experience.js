'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('user_work_experiences', {
      experience_id:{
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        type:DataTypes.UUID
      },
      company_name:{
        allowNull:true,
        type:DataTypes.STRING
      },
      internship_type:{
        allowNull:true,
        type:DataTypes.STRING
      },
      company_link:{
        allowNull:true,
        type:DataTypes.STRING
      },
      internship_title:{
        type:DataTypes.STRING,
        allowNull:true
      },
      company_location:{
        type:DataTypes.STRING
      },
      start_year:{
        type:DataTypes.DATEONLY
      },
      end_year:{
        type:DataTypes.DATEONLY
      },
      description:{
        type:DataTypes.ARRAY(DataTypes.STRING)
      },
      skills:{
        type:DataTypes.ARRAY(DataTypes.STRING)
      },
      certificate_link:{
        type:DataTypes.STRING
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('user_work_experiences');
  }
};