'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('discussion_topics', {
      topic_id:{
        primaryKey:true,
        allowNull:false,
        type:DataTypes.UUID,
        defaultValue:DataTypes.UUIDV4
      },
      user_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      title:{
        type:DataTypes.STRING,
        allowNull:false
      },
      description:{
        type:DataTypes.STRING(2000),
        allowNull:false
      },
      tags:{
        type:DataTypes.ARRAY(DataTypes.STRING),
        allowNull:true
      },
      votes:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      likes:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      views:{
        type:DataTypes.INTEGER,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('discussion_topics');
  }
};