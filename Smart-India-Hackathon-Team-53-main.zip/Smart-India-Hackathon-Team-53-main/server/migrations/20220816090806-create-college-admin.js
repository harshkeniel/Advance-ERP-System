'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('college_admins', {
      admin_id:{
        type:DataTypes.UUID,
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true
      },
      college_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      first_name:{
        type:DataTypes.STRING,
        allowNull:false
      },
      last_name:{
        type:DataTypes.STRING,
        allowNull:true
      },
      username:{
        type:DataTypes.STRING,
        allowNull:false
      },
      password:{
        type:DataTypes.STRING,
        allowNull:false
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('college_admins');
  }
};