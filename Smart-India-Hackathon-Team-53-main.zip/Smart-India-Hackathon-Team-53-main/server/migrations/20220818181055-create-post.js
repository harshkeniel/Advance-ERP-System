'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('posts', {
      post_id:{
        type:DataTypes.UUID,
        primaryKey:true,
        allowNull:false,
        defaultValue:DataTypes.UUIDV4
      },
      project_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      user_id:{
        type:DataTypes.UUID,
        allowNull:false
      },
      title:{
        allowNull:false,
        type:DataTypes.STRING
      },
      description:{
        allowNull:false,
        type:DataTypes.STRING(1000)
      },
      post_image:{
        allowNull:true,
        type:DataTypes.STRING
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('posts');
  }
};