'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('users', {
      user_id: {
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID,
        defaultValue:DataTypes.UUIDV4
      },
      college_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      first_name:{
        allowNull:false,
        type:DataTypes.STRING
      },
      last_name:{
        allowNull:false,
        type:DataTypes.STRING
      },
      email:{
        allowNull:false,
        type:DataTypes.STRING
      },
      password:{
        allowNull:false,
        type:DataTypes.STRING
      },
      date_of_birth:{
        allowNull:true,
        type:DataTypes.DATE
      },
      gender:{
        allowNull:true,
        type:DataTypes.STRING
      },
      profile_img:{
        allowNull:true,
        type:DataTypes.STRING
      },
      state:{
        allowNull:true,
        type:DataTypes.STRING
      },
      city:{
        allowNull:true,
        type:DataTypes.STRING
      },
      contact_no:{
        allowNull:true,
        type:DataTypes.STRING
      },
      graduation_start_date:{
        allowNull:true,
        type:DataTypes.DATE
      },
      graduation_complete_date:{
        allowNull:true,
        type:DataTypes.DATE
      },
      skills:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.JSON)
      },
      internship:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.JSON)
      },
      description:{
        allowNull:true,
        type:DataTypes.STRING
      },
      achievements:{
        allowNull:true,
        type:DataTypes.ARRAY(DataTypes.JSON)
      },
      last_logged_in:{
        allowNull:true,
        type:DataTypes.DATE
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('users');
  }
};