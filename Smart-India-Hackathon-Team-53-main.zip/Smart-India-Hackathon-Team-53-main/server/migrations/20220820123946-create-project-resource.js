'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('project_resources', {
      resource_id:{
        allowNull:false,
        primaryKey:true,
        defaultValue:DataTypes.UUIDV4,
        type:DataTypes.UUID
      },
      project_id:{
        allowNull:false,
        type:DataTypes.UUID
      },
      resource_type:{
        type:DataTypes.STRING,
        allowNull:false
      },
      image_url:{
        type:DataTypes.STRING,
        allowNull:true
      },
      link_url:{
        type:DataTypes.STRING,
        allowNull:true
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('project_resources');
  }
};