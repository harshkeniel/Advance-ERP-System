'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('user_domain_mappings', {
      user_id:{
        type:DataTypes.UUID,
        allowNull:false,
        primaryKey:true
      },
      domain_id:{
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('user_domain_mappings');
  }
};