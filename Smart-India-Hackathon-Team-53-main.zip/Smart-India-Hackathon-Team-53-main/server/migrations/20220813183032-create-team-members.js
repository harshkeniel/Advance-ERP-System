'use strict';
module.exports = {
  async up(queryInterface, DataTypes) {
    await queryInterface.createTable('team_members', {
      team_member_id:{
        type:DataTypes.UUID,
        primaryKey:true,
        allowNull:false
     },
     team_id:{
       allowNull:false,
       type:DataTypes.UUID,
       primaryKey:true
     },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });
  },
  async down(queryInterface, DataTypes) {
    await queryInterface.dropTable('team_members');
  }
};