'use strict';
module.exports = {
  async up(queryInterface, Datatypes) {
    await queryInterface.createTable('user_educations', {
      education_id:{
        allowNull:false,
        defaultValue:DataTypes.UUIDV4,
        primaryKey:true,
        type:DataTypes.UUID
      },
      university_name:{
        allowNull:true,
        type:DataTypes.STRING
      },
      study_field:{
        allowNull:true,
        type:DataTypes.STRING
      },
      degree:{
        allowNull:true,
        type:DataTypes.STRING
      },
      grade:{
        type:DataTypes.FLOAT,
        allowNull:true
      },
      start_year:{
        type:DataTypes.DATEONLY
      },
      end_year:{
        type:DataTypes.DATEONLY
      },
      createdAt: {
        allowNull: false,
        type: Datatypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Datatypes.DATE
      }
    });
  },
  async down(queryInterface, Datatypes) {
    await queryInterface.dropTable('user_educations');
  }
};