const jwt = require('jsonwebtoken');
const spawn = require('child_process').spawn;

const auth = async (req, res, next) => {
    try{
        const auth_header = req.headers.authorization;
        if(auth_header){
            const token = auth_header.split(' ')[1];
            let data = await jwt.verify(token,process.env.JWT_SECRET_SIGNATURE);
            req.user = {"id":"f17fa9ec-241f-4fa5-aea8-1059858bfcbf"};
            next();
        }
        else{
            res.status(401).json({
                status:"failure",
                msg:"Token Not Found"
            });
        }
    }
    catch(err){
        res.status(500).json({
            status:"failure",
            error:err.message
        });
    }
}


module.exports = {auth};