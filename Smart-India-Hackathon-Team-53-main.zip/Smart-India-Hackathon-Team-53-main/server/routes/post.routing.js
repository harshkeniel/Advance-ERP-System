const express = require('express');
const router = express.Router();

const postController = require("../controllers/post.controller");
const {auth} = require("../middlewares/auth");

router.route("/create")
      .post(postController.create_post);

router.route("/:id")
      .get(postController.get_post)
      .put(auth,postController.update_post)
      .delete(auth,postController.delete_post)

router.route("/:id/info")
      .get(postController.get_post_info)

router.route("/:id/clap")
      .get(postController.get_claps)
      .post(auth,postController.handle_clap_unclap)

router.route("/:id/save")
      .post(auth,postController.handle_save_unsave)

// router.route("/:id/unclap")
//       .delete(auth,postController.handle_unclap)

router.route("/:id/comments")
      .get(postController.get_post_comments)

module.exports = router;