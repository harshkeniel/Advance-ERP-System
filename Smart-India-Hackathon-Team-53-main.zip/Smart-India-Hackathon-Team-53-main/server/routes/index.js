const express = require('express');
const router = express.Router();

const userRouting = require("./user.routing")
const collegeRouting = require("./college.routing");
const feedRouting = require("./feed.routing");
const teamRouting = require("./team.routing");
const projectRouting = require("./project.routing");
const dropdownRouting = require("./dropdown.routing");
const postRouting = require("./post.routing");
const commentsRouting = require("./comments.routing");
const communityRouting = require("./community.routing");
const facultyRouting = require("./faculty.routing");
const classroomRouting = require("./classroom.routing");
const fileRouting = require("./files.routing");
const plagiarismRouting = require("./plagiarism.routing");
const organizationRouting = require("./organization.routing");

router.use("/user",userRouting);
router.use("/college",collegeRouting);
router.use("/feed",feedRouting);
router.use("/team",teamRouting);
router.use("/project",projectRouting);
router.use("/dropdown",dropdownRouting);
router.use("/post",postRouting);
router.use("/comment",commentsRouting);
router.use("/community",communityRouting);
router.use("/faculty",facultyRouting);
router.use("/classroom",classroomRouting);

router.use("/file", fileRouting);

router.use("/plagiarism", plagiarismRouting);
router.use("/organization",organizationRouting);

module.exports = router;