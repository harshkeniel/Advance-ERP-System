const express = require('express');
const router = express.Router();

const classroomController = require("../controllers/classroom.controller");
const {auth} = require("../middlewares/auth");

router.route("/create")
      .post(auth,classroomController.create_classroom);

router.route("/:id")
      .get(classroomController.get_classroom)
      .put(auth,classroomController.edit_classroom)
      .delete(auth,classroomController.delete_classroom)

router.route("/:id/assignment")
      .get(classroomController.get_all_assignments)
      .post(auth,classroomController.create_assignment)

router.route("/:id/assignment/:assignment_id")
      .get(classroomController.get_assignment)
      .put(auth,classroomController.edit_assignment)
      .delete(auth,classroomController.delete_assignment)

router.route("/:id/assignment/:assignment_id/submission")
      .post(classroomController.add_submission)
      .get(classroomController.get_all_submissions)

router.route("/:id/assignment/:assignment_id/submission/:sub_id")
      .get(classroomController.get_submission)

router.route("/:id/assignment/:assignment_id/submission/:sub_id/score")
      .post(classroomController.assign_score)

module.exports = router;