const express = require('express');
const router = express.Router();

const fileController = require("../controllers/files.controller");

router.route("/upload")
      .post(fileController.upload_file);

module.exports = router;