const express = require('express');
const router = express.Router();

const plagiarismController = require("../controllers/plagiarism.controller");

router.route("/docs")
      .post(plagiarismController.check_doc);

router.route("/project")
      .get(plagiarismController.check_project)

module.exports = router;