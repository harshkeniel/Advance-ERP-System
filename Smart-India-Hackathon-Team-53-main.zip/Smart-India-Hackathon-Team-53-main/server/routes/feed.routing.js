const express = require('express');
const router = express.Router();

const feedController = require("../controllers/feed.controller");
const {auth} = require("../middlewares/auth")

router.route("/user")
      .get(auth,feedController.get_user_feed);

router.route("/trending")
      .get(auth,feedController.get_trending_posts);

router.route("/college")
      .get(auth,feedController.get_college_feed);

router.route("/board")
      .get(auth,feedController.get_feed_by_domain);

module.exports = router;