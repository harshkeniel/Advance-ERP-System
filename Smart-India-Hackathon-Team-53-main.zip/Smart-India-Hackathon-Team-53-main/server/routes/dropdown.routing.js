const express = require('express');
const router = express.Router();

const dropdownsController = require("../controllers/dropdowns.controller");

router.route("/domain")
      .get(dropdownsController.get_all_boards)
      .post(dropdownsController.add_board)
      
router.route("/domain/:id")
      .get(dropdownsController.get_single_board)
      .put(dropdownsController.update_board)
      .delete(dropdownsController.delete_board)

router.route("/tech_stack")
      .get(dropdownsController.get_tech_stack)

module.exports = router;