const express = require('express');
const router = express.Router();

const teamController = require("../controllers/team.controller");
const {auth} = require("../middlewares/auth");

router.route("/create")
      .post(auth,teamController.create_team)

router.route("/:id")
      .get(auth,teamController.get_single_team)
      
router.route("/:id/member")
      .get(auth,teamController.get_all_team_members)
      .post(auth,teamController.add_member)

router.route("/:id/member/:member_id")
      .delete(auth,teamController.remove_member)

module.exports = router;