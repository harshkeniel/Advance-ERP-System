const express = require('express');
const router = express.Router();

const projectController = require("../controllers/project.controller");
const {auth} = require("../middlewares/auth");

router.route("/:id")
      .get(projectController.get_project)
      .put(auth,projectController.update_project)
      .delete(auth,projectController.delete_project)

router.route("/create")
      .post(auth,projectController.create_project)

router.route("/:id/resource")
      .get(projectController.get_project_resource)
      .post(auth,projectController.add_project_resource)

router.route("/:id/link")
      .get(projectController.get_project_links)
      .post(auth,projectController.add_project_link)

router.route("/:id/media")
      .get(projectController.get_project_media)
      .post(auth,projectController.add_project_media)

router.route("/:id/task")
      .get(auth,projectController.get_all_tasks)
      .post(auth,projectController.add_project_task)

router.route("/:id/task/:task_id")
      .get(auth,projectController.get_single_task)
      .put(auth,projectController.update_task_status)
      .delete(auth,projectController.delete_task)

router.route("/:id/story")
      .get(projectController.get_all_stories)
      .post(auth,projectController.add_new_story)

router.route("/:id/story/:story_id")
      .get(projectController.get_story)
      .put(auth,projectController.edit_story)
      .delete(auth,projectController.delete_story)

router.route("/:id/similar")
      .get(projectController.get_similar_projects)

// router.route("/similarity/score")
//       .get(projectController.get_similarity_score)

module.exports = router;