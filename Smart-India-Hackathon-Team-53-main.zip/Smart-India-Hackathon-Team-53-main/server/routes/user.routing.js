const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const {auth} = require("../middlewares/auth");

router.route("/login")
      .post(userController.login);

router.route("/signup")
      .post(userController.signup);

router.route("/:id")
      .get(userController.get_user_profile)
      .put(auth,userController.update_user_profile)

router.route("/:id/follow")
      .post(userController.follow_user)

router.route("/:id/unfollow")
      .post(auth,userController.unfollow_user)

router.route("/:id/projects/personal")
      .get(userController.get_personal_projects)

router.route("/:id/teams")
      .get(auth,userController.get_all_teams)

router.route("/:id/posts")
      .get(userController.get_all_posts)

router.route("/:id/updates")
      .get(auth,userController.get_project_updates)

router.route("/:id/project/analytics")
      .get(auth,userController.get_project_analytics)

router.route("/:id/domain/:domain_id/star")
      .post(auth,userController.star_domain)

router.route("/:id/domain/:domain_id/unstar")
      .post(auth,userController.unstar_domain)

module.exports = router;