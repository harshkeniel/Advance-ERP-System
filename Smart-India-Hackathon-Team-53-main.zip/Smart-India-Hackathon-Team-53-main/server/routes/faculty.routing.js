const express = require('express');
const router = express.Router();

const facultyController = require("../controllers/faculty.controller");

router.route("/login")
      .post(facultyController.login);

router.route("/signup")
      .post(facultyController.signup)

router.route("/:id")
      .get(facultyController.get_profile)
    
module.exports = router;