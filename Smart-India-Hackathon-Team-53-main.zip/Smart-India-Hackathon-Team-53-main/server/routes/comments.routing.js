const express = require('express');
const router = express.Router();

const commentsController = require("../controllers/comments.controller");
const {auth} = require("../middlewares/auth");

router.route("/")
      .post(auth,commentsController.add_comment)

router.route("/:id")
      .get(commentsController.get_single_comment)
      .put(auth,commentsController.edit_comment)
      .delete(auth,commentsController.delete_comment)

router.route("/:id/upvote")
      .post(auth,commentsController.add_upvote)

router.route("/:id/downvote")
      .post(auth,commentsController.add_downvote)

module.exports = router;