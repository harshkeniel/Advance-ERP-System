const express = require('express');
const router = express.Router();

const organizationController = require("../controllers/organization.controller");

// router.route("/job")
//       .post(organizationController.add_job)
//       .get(organizationController.get_all_jobs)

// router.route("/job/:id")
//       .get(organizationController.get_job)


module.exports = router;