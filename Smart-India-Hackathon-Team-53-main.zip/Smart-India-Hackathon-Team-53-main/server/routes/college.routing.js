const express = require('express');
const router = express.Router();

const collegeController = require("../controllers/college.controller");

router.route("/admin_login").post(collegeController.admin_login);
router.route("/college_signup").post(collegeController.college_signup);
router.route("/admin_signup").post(collegeController.admin_signup);


router.route("/:id")
      .get(collegeController.get_profile)
      .put(collegeController.update_profile)

module.exports = router;