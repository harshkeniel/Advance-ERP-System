const express = require('express');
const router = express.Router();

const communityController = require("../controllers/community.controller");
const {auth} = require("../middlewares/auth");

router.route("/topic")
      .get(communityController.get_all_topics)
      .post(auth,communityController.add_topic)

router.route("/topic/:id")
      .get(communityController.get_single_topic)
      .put(auth,communityController.edit_topic)
      .delete(auth,communityController.delete_topic)

router.route("/topic/:id/view")
      .post(auth,communityController.add_view)

router.route("/topic/:id/upvote")
      .post(auth,communityController.upvote)

router.route("/topic/:id/downvote")
      .post(auth,communityController.downvote)

router.route("/topic/:id/comments")
      .get(communityController.get_topic_comments)

module.exports = router;