import psycopg2
from dotenv import load_dotenv
import pandas as pd
import os
import nltk
import sys
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json
import psycopg2.extras
psycopg2.extras.register_uuid()

ps = PorterStemmer()
cv = CountVectorizer(max_features = 5000, stop_words = 'english')

DB_NAME = os.getenv("DB_NAME")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_USERNAME = os.getenv("DB_USERNAME")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")

def stem(text):
    y = []
    for i in text.split():
        y.append(ps.stem(i))
    return " ".join(y)

# def recommend(id,df,similarity):
#     index = df[df['id'] == id].index[0]
#     distances = sorted(list(enumerate(similarity[index])),reverse=True,key = lambda x: x[1])
#     similar_ids = []
#     for i in distances[1:6]:
#         similar_ids.append(df.iloc[i[0]]['id'])
#     return similar_ids

def recommendationSystem(project_1_id,project_2_id):
    #establishing the connection
    try:
        conn = psycopg2.connect(
            database = DB_NAME,
            user = DB_USERNAME,
            password = DB_PASSWORD,
            host = DB_HOST,
            port = DB_PORT
        )
        # print("Database connected successfully")
        
    except(Exception, psycopg2.Error) as error:
        pass
        # print("Database not connected successfully")
    
    #Creating a cursor object using the cursor() method
    cursor = conn.cursor()

    select_query = f"SELECT project_id,name,idea_description,tags,tech_stack FROM projects where project_id = '{project_1_id}' OR project_id = '{project_2_id}'"
    cursor.execute(select_query)
    data = cursor.fetchall()
    # print(data)    
    # print('Data fetched successfully')

    # df = pd.DataFrame(data, columns=['id', 'title', 'description','domain','tags','tech_stack'])
    df = pd.DataFrame(data, columns=['id', 'title', 'description','tags','tech_stack'])
    #print(df)
    df['tags'] = [','.join(map(str, l)) for l in df['tags']]
    # df['domain'] = [','.join(map(str, l)) for l in df['domain']]
    df['tech_stack'] = [','.join(map(str, l)) for l in df['tech_stack']]


    df['tags'] = df['tags'].apply(lambda x : [x])
    # df['domain'] = df['domain'].apply(lambda x : [x])
    df['tech_stack'] = df['tech_stack'].apply(lambda x : [x])


    df['description'] = df['description'].apply(lambda x: x.split())
    # df['final_tags'] = df['description'] + df['domain'] + df['tags'] + df['tech_stack'] 
    df['final_tags'] = df['description'] +  df['tags'] + df['tech_stack'] 

    
    new_df = df[['id', 'title', 'final_tags']]
    new_df['final_tags'] = new_df['final_tags'].apply(lambda x: " ".join(x))
    new_df['final_tags'] = new_df['final_tags'].apply(lambda x: x.lower())
    
    new_df['final_tags'] = new_df['final_tags'].apply(stem)

    vectors = cv.fit_transform(new_df['final_tags']).toarray()
    similarity = cosine_similarity(vectors)
    score = similarity[0][1]
    
    print(score)

    conn.commit()
    
    #Closing the connection
    conn.close()

project_1_id = sys.argv[1]
project_2_id = sys.argv[2]
recommendationSystem(project_1_id,project_2_id)