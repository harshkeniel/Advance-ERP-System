import psycopg2
from dotenv import load_dotenv
import pandas as pd
import os
import nltk
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json
import psycopg2.extras
psycopg2.extras.register_uuid()

ps = PorterStemmer()
cv = CountVectorizer(max_features = 5000, stop_words = 'english')

DB_NAME = os.getenv("DB_NAME")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_USERNAME = os.getenv("DB_USERNAME")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")

def stem(text):
    y = []
    for i in text.split():
        y.append(ps.stem(i))
    return " ".join(y)

def recommend(id,df,similarity):
    index = df[df['id'] == id].index[0]
    distances = sorted(list(enumerate(similarity[index])),reverse=True,key = lambda x: x[1])
    similar_ids = []
    for i in distances[1:6]:
        similar_ids.append(df.iloc[i[0]]['id'])
    return similar_ids

def recommendationSystem():
    #establishing the connection
    try:
        conn = psycopg2.connect(
            database = DB_NAME,
            user = DB_USERNAME,
            password = DB_PASSWORD,
            host = DB_HOST,
            port = DB_PORT
        )
        print("Database connected successfully")
        
    except(Exception, psycopg2.Error) as error:
        print("Database not connected successfully")
    
    #Creating a cursor object using the cursor() method
    cursor = conn.cursor()

    cursor.execute("""
        SELECT project_id,name,idea_description,tags,tech_stack FROM projects
    """)
    data = cursor.fetchall()
    #print(data)    
    print('Data fetched successfully')

    df = pd.DataFrame(data, columns=['id', 'name', 'idea_description','tags','tech_stack'])
    #print(df)
    df['tags'] = [','.join(map(str, l)) for l in df['tags']]
    # df['domain'] = [','.join(map(str, l)) for l in df['domain']]
    df['tech_stack'] = [','.join(map(str, l)) for l in df['tech_stack']]

    df['tags'] = df['tags'].apply(lambda x : [x])
    # df['domain'] = df['domain'].apply(lambda x : [x])
    df['tech_stack'] = df['tech_stack'].apply(lambda x : [x])


    df['idea_description'] = df['idea_description'].apply(lambda x: x.split())
    df['final_tags'] = df['idea_description'] + df['tags'] + df['tech_stack'] 
    
    new_df = df[['id', 'name', 'final_tags']]
    new_df['final_tags'] = new_df['final_tags'].apply(lambda x: " ".join(x))
    new_df['final_tags'] = new_df['final_tags'].apply(lambda x: x.lower())
    
    new_df['final_tags'] = new_df['final_tags'].apply(stem)

    vectors = cv.fit_transform(new_df['final_tags']).toarray()
    similarity = cosine_similarity(vectors)

    find_query = f"SELECT project_id FROM similar_projects"
    cursor.execute(find_query)
    find_query_results = cursor.fetchall()
    updated_data = []
    for i in find_query_results:
        updated_data.append(i[0])
    
    print(updated_data)
    #UPDATE Customers SET ContactName = 'Alfred Schmidt', City= 'Frankfurt' WHERE CustomerID = 1;
    for i in range(0,len(new_df)):
        similar_ids = recommend(new_df['id'][i],new_df,similarity)
        print(len(similar_ids))
        query = ""
        if new_df['id'][i] in updated_data:
            print("Update query")
            
            query = f"UPDATE similar_projects SET \"similar\" = ARRAY {similar_ids} WHERE project_id = '{new_df['id'][i]}';"

        else:
            query = f"INSERT INTO similar_projects VALUES('{new_df['id'][i]}',ARRAY {similar_ids});"
            print("Insert Query")

        print("Query ",query)
        try:
            cursor.execute(query)
        except(Exception, psycopg2.Error) as error:
            print(error)

    conn.commit()
    
    #Closing the connection
    conn.close()


recommendationSystem()