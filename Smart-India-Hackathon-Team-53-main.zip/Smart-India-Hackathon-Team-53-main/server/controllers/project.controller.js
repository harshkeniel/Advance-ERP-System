const { spawnSync } = require("child_process");
const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User,Project,Team,TeamMembers,ProjectResource,ProjectLink,ProjectMedia,ProjectTask,
ProjectStory,SimilarProject } = require("../models");
// const spawn = require('child_process').spawnSync;

class ProjectController {

    async create_project(req,res){
        try{
            let data = await Project.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Project Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Project Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_project(req,res){
        try{
            let data = await Project.findOne({
                where:{ project_id:req.params.id },
                include:[
                    {
                        model:Team,
                        as:'project_team',
                        include:{ 
                            model:TeamMembers,
                            as:'team_members',
                            include:{
                                model:User,
                                as:'user',
                                attributes:["user_id","profile_img","first_name","last_name"]
                            }
                        }
                    },
                    {
                        model:ProjectResource,
                        as:'project_resources'
                    },
                    {
                        model:ProjectLink,
                        as:'project_links'
                    },
                    {
                        model:ProjectMedia,
                        as:'project_media'
                    }
                ]
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async update_project(req,res){
        try{
            let data = await Project.update(req.body,{
                where:{
                    project_id:req.params.id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_project(req,res){
        try{
            let data = await Project.destroy({
                where:{
                    project_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Project Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Project Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_project_resource(req,res){
        try{
            let data = await ProjectResource.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Resource Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Resource Not Added"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_project_link(req,res){
        try{
            let data = await ProjectLink.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Link Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Link Not Added"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_project_media(req,res){
        try{
            let data = await ProjectMedia.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Project Media Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Project Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_project_resource(req,res){
        try{
            let data = await ProjectResource.findAll({
                where:{
                    project_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_project_links(req,res){
        try{
            let data = await ProjectLink.findAll({
                where:{
                    project_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_project_media(req,res){
        try{
            let data = await ProjectMedia.findAll({
                where:{
                    project_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_all_tasks(req,res){
        try{
            let data = await ProjectTask.findAll({
                where:{
                    project_id:req.params.id
                },
                include:{
                    model:User,
                    as:"user",
                    attributes:["user_id","profile_img","first_name","last_name"]
                }
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_single_task(req,res){
        try{
            let data = await ProjectTask.findAll({
                where:{
                    task_id:req.params.id
                },
                include:{
                    model:User,
                    as:"'user",
                    attributes:["user_id","profile_img","first_name","last_name"]
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_project_task(req,res){
        try{
            let member_found = await TeamMembers.findOne({
                where:{
                    team_member_id:req.body.assigned_to
                }
            });
            if(!member_found){
                return res.status(404).json({
                    status:"failure",
                    msg:"Memebr not found in team"
                });
            }
            let data = await ProjectTask.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Task Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Task Not Added"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async update_task_status(req,res){
        try{
            let member_found = await TeamMembers.findOne({
                where:{team_member_id:req.user.id}
            });
            if(!member_found){
                return res.status(401).json({
                    status:"failure",
                    msg:"Member not found in team"
                });
            }
            let data = await ProjectTask.update({status:req.body.status},{
                where:{
                    task_id:req.params.task_id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_task(req,res){
        try{
            let member_found = await TeamMembers.findOne({
                where:{team_member_id:req.user.id}
            });
            if(!member_found){
                return res.status(401).json({
                    status:"failure",
                    msg:"Memebr not found in team"
                });
            }
            let data = await ProjectTask.destroy({
                where:{
                    task_id:req.params.task_id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Task Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Task Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_new_story(req,res){
        try{
           
            let data = await ProjectStory.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Story Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Story Not Added"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_all_stories(req,res){
        try{
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let data = await ProjectStory.findAll({
                offset,limit,
                include:{
                    model:User,
                    as:"user",
                    attributes:["user_id","profile_img","first_name","last_name"]
                },
                order:[["createdAt",req.query.order]]
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_story(req,res){
        try{
            let data = await ProjectStory.findOne({
                where:{
                    story_id:req.params.story_id
                },
                include:{
                    model:User,
                    as:"user",
                    attributes:["user_id","profile_img","first_name","last_name"]
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async edit_story(req,res){
        try{
            let data = await ProjectStory.update(req.body,{
                where:{
                    story_id:req.params.story_id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }
    
    async delete_story(req,res){
        try{
            let data = await ProjectStory.destroy({
                where:{
                    story_id:req.params.story_id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Story Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Story Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_similar_projects(req,res){
        try{
            let similar = await SimilarProject.findOne({
                where:{
                    project_id:req.params.id
                }
            });

            let data = await Project.findAll({
                where:{
                    [Op.or]:{
                        project_id:similar.similar_projects
                    }
                },
                include:[
                    {
                        model:Team,
                        as:'project_team',
                        attributes:{
                            exclude:["createdAt","updatedAt"]
                        },
                        include:{ 
                            model:TeamMembers,
                            as:'team_members',
                            attributes:{
                                exclude:["createdAt","updatedAt"]
                            },
                            include:{
                                model:User,
                                as:'user',
                                attributes:["user_id","profile_img","first_name","last_name"]
                            }
                        }
                    }
                ]
            });

            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    // async get_similarity_score(req,res){
    //     try{
    //         //console.log(req.score)
    //         // res.json(req.score)
    //         const process = spawnSync('python',["./helpers/similarity_score.py",req.query.id1,req.query.id2]);
    //         const score = process.stdout.toString()
    //         console.log(score)
    //         res.status(200).json({
    //             similarity_score:parseFloat(score)
    //         })
    //     }
    //     catch(err){
    //         console.log(err)
    //         res.status(500).json({
    //             status:"failure",
    //             msg:err.message
    //         });
    //     }
    // }

}

module.exports = new ProjectController();