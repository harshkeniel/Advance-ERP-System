const sequelize = require("sequelize");
const Op = sequelize.Op;
const { DomainBoard,TechStack } = require("../models");

class DomainBoardController {

    async add_board(req,res){
        try{
            let data = await DomainBoard.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Board Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Board Not Created"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_all_boards(req,res){
        try{
            let data = await DomainBoard.findAll({
                attributes:{
                    exclude:["createdAt","updatedAt"]
                }
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"No Boards Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_single_board(req,res){
        try{
            let data = await DomainBoard.findOne({
                where:{board_id:req.params.id}
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"No Boards Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async update_board(req,res){
        try{
            let data = await DomainBoard.update(req.body,{
                where:{board_id:req.params.id}
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update Successful"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Update Unsuccessful"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async delete_board(req,res){
        try{
            let data = await DomainBoard.destroy({
                where:{board_id:req.params.id}
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Board Deleted Successfully"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_tech_stack(req,res){
        try{
            let data = await TechStack.bulkCreate(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Stacks Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Stacks Not Created"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_tech_stack(req,res){
        try{
            let data = await TechStack.findAll();
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failurre",
                msg:err.message
            });
        }
    }

}

module.exports = new DomainBoardController();