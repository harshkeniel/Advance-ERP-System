const sequelize = require("sequelize");
const Op = sequelize.Op;
const path = require("path")

const { File } = require("../models");

class FileController {
    async upload_file(req, res) {
        let uploadPath;

        console.log(req.files)
        
        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).send('No files were uploaded.');
        }
        
        // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
        const fileObject = req.files.sampleFile;
        const [file_name, file_extension] = fileObject.name.split(".")
        
        const {project_id} = req.body

        let file = await File.create({ file_name, file_extension, project_id })
        
        const file_save_name = `${file.file_id}.${file.file_extension}`
        const file_name_to_show = `${file.file_name}.${file.file_extension}`
        uploadPath = path.join(__dirname, '..', 'uploads', 'docs', file_save_name)
        
        // Use the mv() method to place the file somewhere on your server
        fileObject.mv(uploadPath, function(err) {
            if (err)
                return res.status(500).send(err);
        
            res.status(200).json({ name : file_name_to_show});
        });
    }
}

module.exports = new FileController();