const sequelize = require("sequelize");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Op = sequelize.Op;
const { User, Follower, Project, Team, TeamMembers,Post,College,ProjectStory,
UserDomainMapping,DomainBoard,UserWorkExperience,UserPOR,UserAchievement,UserEducation,
UserCertification } = require("../models");

class UserController {

    async login(req, res) {
        try {
            let { email, password } = req.body;
            const user_exists = await User.findOne({
                where: { email }
            });
            if (user_exists) {
                const is_match = await bcrypt.compare(password, user_exists.password);
                if (is_match) {
                    const token = await jwt.sign({ id: user_exists.user_id }, process.env.JWT_SECRET_SIGNATURE);
                    res.status(200).json({
                        status: "success",
                        msg: "Login Successful",
                        token: token
                    });
                }
                else {
                    res.status(401).json({
                        status: "failure",
                        msg: "email or password wrong"
                    });
                }
            }
            else {
                res.status(401).json({
                    status: "failure",
                    msg: "User does not exists"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err
            });
        }
    }

    async signup(req, res) {
        try {
            req.body.password = await bcrypt.hash(req.body.password, 10)
            let data = await User.create(req.body);
            if (data) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(400).json({
                    status: "failure",
                    msg: "Signup Unsuccessful"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err
            });
        }
    }

    async get_user_profile(req, res) {
        try {
            let data = await User.findOne({
                where: {
                    user_id: req.params.id
                },
                attributes:{
                    include : [ 
                        [sequelize.literal('(SELECT COUNT(*) FROM followers WHERE following_id = "User"."user_id")'), "followers_count"],
                        [sequelize.literal('(SELECT COUNT(*) FROM followers WHERE followed_by_id = "User"."user_id")'), "following_count"]
                    ],
                    exclude:["createdAt","updatedAt"]
                },
                include: [
                    // {
                    //     model: User,
                    //     as: "followers",
                    //     through: { attributes: [] },
                    //     attributes: ["user_id", "first_name"]
                    // },
                    // {
                    //     model: User,
                    //     as: "following",
                    //     through: { attributes: [] },
                    //     attributes: ["user_id", "first_name"]
                    // },s
                    {
                        model: College,
                        as:'college',
                        attributes:["college_id","college_name"]
                    },
                    {
                        model:UserDomainMapping,
                        as:'followed_domains',
                        include:{
                            model:DomainBoard,
                            as:'domains'
                        }
                    },
                    {
                        model:UserWorkExperience,
                        as:'experiences'
                    },
                    {
                        model:UserCertification,
                        as:'certifications'
                    },
                    {
                        model:UserEducation,
                        as:'educations'
                    },
                    {
                        model:UserPOR,
                        as:'pors'
                    },
                    {
                        model:UserAchievement,
                        as:'achievements'
                    }
                ]
            });
            if (data) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "No data Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async update_user_profile(req, res) {
        try {
            let data = await User.update(req.body, {
                where: {
                    user_id: req.params.id
                }
            });
            if (data[0]) {
                res.status(200).json({
                    status: "success",
                    msg: "Update SuccessFul"
                });
            }
            else {
                res.status(400).json({
                    status: "failure",
                    msg: "User not Found, Update Failed !"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err.message
            });
        }
    }

    async get_followers_count(req, res) {
        try {
            let data = await Follower.count({
                where: { following_id: req.params.user_id }
            });
            res.status(200).json({
                followers_count: data
            });
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async follow_user(req, res) {
        try {
            let { id } = req.user;
            let is_following = await Follower.findOne({
                where: {
                    following_id: req.params.id,
                    followed_by_id: id
                }
            });
            if (!is_following) {
                let data = await Follower.create({
                    following_id: req.params.id,
                    followed_by_id: id
                });
                if (data) {
                    res.status(200).json({
                        status: "success",
                        msg: "User Followed Successfully"
                    });
                }
                else {
                    res.status(400).json({
                        status: "failure",
                        msg: "Error While following user"
                    });
                }
            }
            else {
                res.status(400).json({
                    status: "failure",
                    msg: "User Already Followed"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async unfollow_user(req, res) {
        try {
            let { id } = req.user;
            let is_following = await Follower.findOne({
                where: {
                    following_id: req.params.id,
                    followed_by_id: id
                }
            });
            if (is_following) {
                let data = await Follower.destroy({
                    where: {
                        following_id: req.params.id,
                        followed_by_id: id
                    }
                });
                if (data) {
                    res.status(200).json({
                        status: "success",
                        msg: "User Unfollowed Successfully"
                    });
                }
                else {
                    res.status(400).json({
                        status: "failure",
                        msg: "Error While Unfollowing user"
                    });
                }
            }
            else {
                res.status(400).json({
                    status: "failure",
                    msg: "User Is already Unfollowing"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_personal_projects(req, res) {
        try {
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let data = await Project.findAll({
                offset, limit,
                where: { user_id: req.params.id },
                include:{
                    model:Team,
                    as:'project_team',
                    include:{
                        model:TeamMembers,
                        as:'team_members',
                        attributes:{
                            exclude:['createdAt','updatedAt']
                        }
                    },
                    attributes:{
                        exclude:['createdAt','updatedAt']
                    },
                },
                attributes:{
                    exclude:['createdAt','updatedAt']
                }
            });
            let total_count = await Project.count({
                where: { user_id: req.params.id }
            });

            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    total_projects: total_count,
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "Data not Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err.message
            });
        }
    }

    async get_all_teams(req, res) {
        try {
            let data = await Team.findAll({
                where: { leader_id: req.params.id },
                include: {
                    model: TeamMembers,
                    as:'team_members'
                }
            });
            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "No Teams Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_all_posts(req, res) {
        try {
            let data = await Post.findAll({
                where: { user_id: req.params.id }
            });
            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "No Posts Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_project_updates(req,res){
        try {
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }

            let following_users = await Follower.findAll({
                where:{followed_by_id:req.user.id},
                attributes:["following_id"],
                order:[["createdAt","DESC"]]
            });

            let as_leaders = await Project.findAll({
                where:{
                    [Op.or]: [
                        { user_id: following_users.map((record) => record.following_id) }
                    ]
                },
                attributes:["project_id"],
                raw:true
            });

            let as_members = await TeamMembers.findAll({
                where:{
                    [Op.or]: [
                        { team_member_id: following_users.map((record) => record.following_id) }
                    ]
                },
                include:{
                    model:Team,
                    as:'team',
                    attributes:["team_id"],
                    include:{
                        model:Project,
                        as:'project',
                        attributes:["project_id"]
                    }
                },
                raw:true
            });

            let all_projects = as_leaders.concat(as_members);
            
            let data = await ProjectStory.findAll({
                offset,limit,
                where:{
                    [Op.or]: [
                        { project_id: all_projects.map((record) => record.project_id) }
                    ]
                },
                order:[["createdAt","DESC"]]
            });

            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "No Updates Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_project_analytics(req,res){
        try {
            let personal_projects = await Project.count({
                where:{user_id:req.params.id}
            });
            let published_projects = await Project.count({
                where:{
                    user_id:req.params.id,
                    visibility:'public'
                }
            });
            let private_projects = await Project.count({
                where:{
                    user_id:req.params.id,
                    visibility:'private'
                }
            });
            let total_projects = await Project.count({
                where:{user_id:req.params.id}
            });

            if (total_projects) {
                res.status(200).json({
                    status: "success",
                    total_projects,
                    personal_projects,
                    published_projects,
                    private_projects
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "Data not Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err.message
            });
        }
    }

    async star_domain(req,res){
        try{
            let data = await UserDomainMapping.create({
                user_id:req.params.id,
                domain_id:req.params.domain_id
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Domain Starred",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Domain Not Starred"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async unstar_domain(req,res){
        try{
            let data = await UserDomainMapping.destroy({
                where:{
                    user_id:req.params.id,
                    domain_id:req.params.domain_id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Domain UnStarred",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Error occurred"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

}

module.exports = new UserController();