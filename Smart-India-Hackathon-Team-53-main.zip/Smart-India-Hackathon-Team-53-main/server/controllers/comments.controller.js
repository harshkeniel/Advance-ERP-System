const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User,Comment,CommentReply } = require("../models");

class CommentsController {

    async add_comment(req,res){
        try{
            let data;
            if(!req.body.comment_id){
                data = await Comment.create(req.body);
            }
            else{
                data = await CommentReply.create(req.body);
            }
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Comment Added Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Comment not Added"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_single_comment(req,res){
        try{
            let data = await Comment.findOne({
                where:{comment_id:req.params.id},
                include:{
                    model:CommentReply,
                    as:'comment_replies'
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                })
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Comment Not Found"
                })
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async edit_comment(req,res){
        try{
            let data;
            if(!req.body.comment_id){
                data = await Comment.update(req.body,{
                    where:{
                        comment_id:req.params.id
                    }
                });
            }
            else{
                data = await CommentReply.update(req.body,{
                    where:{
                        reply_id:req.params.id
                    }
                });
            }

            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_comment(req,res){
        try{
            let data;
            if(!req.body.comment_id){
                data = await Comment.destroy({
                    where:{
                        comment_id:req.params.id
                    }
                });
            }
            else{
                data = await CommentReply.destroy({
                    where:{
                        reply_id:req.params.id
                    }
                });
            }
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Comment Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Comment Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_upvote(req,res){
        try{
            let data;
            if(!req.body.comment_id){
                data = await Comment.increment('votes',
                    {
                        where:{comment_id:req.params.id}
                    }
                )
            }
            else{
                data = await CommentReply.increment("votes",
                    {
                        where:{reply_id:req.params.id}
                    }
                )
            }

            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Upvoted"
                });
            }
            else{
                
                res.status(400).json({
                    status:"failure",
                    msg:"Error Occured"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_downvote(req,res){
        try{
            let data;
            if(!req.body.comment_id){
                data = await Comment.decrement("votes",
                    {
                        where:{comment_id:req.params.id}
                    }
                )
            }
            else{
                data = await CommentReply.decrement("votes",
                    {
                        where:{reply_id:req.params.id}
                    }
                )
            }
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Downvoted"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Error Occurred"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }
}

module.exports = new CommentsController();