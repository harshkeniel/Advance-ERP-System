const sequelize = require("sequelize");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Op = sequelize.Op;
const {User,College,CollegeAdmin} = require("../models");

class CollegeController {

    async admin_login(req,res){
        try {
            let { username, password } = req.body;
            const admin_exists = await CollegeAdmin.findOne({
                where: { username }
            });
            if (admin_exists) {
                const is_match = await bcrypt.compare(password, admin_exists.password);
                if (is_match) {
                    const token = await jwt.sign({ id:admin_exists.admin_id }, process.env.JWT_SECRET_SIGNATURE);
                    res.status(200).json({
                        status: "success",
                        msg: "Login Successful",
                        token: token
                    });
                }
                else {
                    res.status(401).json({
                        status: "failure",
                        msg: "username or password wrong"
                    });
                }
            }
            else {
                res.status(401).json({
                    status: "failure",
                    msg: "Admin does not exists"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({ 
                status: "failure",
                error:err
            });
        }
    }

    async admin_signup(req,res){
        try{
            req.body.password = await bcrypt.hash(req.body.password,10)
            let data = await CollegeAdmin.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Signup Unsuccessful"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err
            });
        }
    }

    async college_signup(req,res){
        try{
            let data = await College.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Signup Unsuccessful"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err
            });
        }
    }

    async get_profile(req,res){
        try{
            let data = await College.findOne({
                where:{ college_id:req.params.id }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async update_profile(req,res){
        try{
            let data = await College.update(req.body,{
                where:{ college_id:req.params.id }
            });

            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update Successful"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"College not Found,Update Unsuccessful"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }
}

module.exports = new CollegeController();