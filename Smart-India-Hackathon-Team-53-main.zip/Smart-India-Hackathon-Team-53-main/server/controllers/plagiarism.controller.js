const sequelize = require("sequelize");
const Op = sequelize.Op;
const path = require("path")
const md5File = require('md5-file')
const { spawnSync } = require("child_process");

class PlagiarismController {
    async check_doc(req, res) {
        const filename1 = req.body.file1
        const filename2 = req.body.file2


        const hash1 = await md5File(path.join('uploads', 'docs', filename1));
        const hash2 = await md5File(path.join('uploads', 'docs', filename2));
        
        res.json({
            plagiarised : hash1 === hash2
        })

    }

    async check_project(req,res){
        try{
            const process = spawnSync('python',["./helpers/similarity_score.py",req.query.id1,req.query.id2]);
            const score = process.stdout.toString()
            //console.log(score)
            res.status(200).json({
                similarity_score:parseFloat(score)
            })
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

}

module.exports = new PlagiarismController();