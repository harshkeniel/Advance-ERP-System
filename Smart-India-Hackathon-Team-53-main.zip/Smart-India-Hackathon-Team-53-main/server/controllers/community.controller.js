const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User,DiscussionTopic,Comment,CommentReply } = require("../models");

class CommunityController {
    
    async get_all_topics(req,res){
        try{
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let data = await DiscussionTopic.findAll({
                offset,limit,
                order:[["createdAt",req.query.order]]
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_topic(req,res){
        try{
            let data = await DiscussionTopic.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Topic Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Topic Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_single_topic(req,res){
        try{
            let data = await DiscussionTopic.findOne({
                where:{ topic_id:req.params.id }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async edit_topic(req,res){
        try{
            let data = await DiscussionTopic.update(req.body,{
                where:{
                    topic_id:req.params.id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_topic(req,res){
        try{
            let data = await DiscussionTopic.destroy({
                where:{
                    topic_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Topic Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Topic Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_view(req,res){
        try{
            let data = await DiscussionTopic.increment('views',
                    {where:{topic_id:req.params.id}
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"View Added"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Error Occured"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async upvote(req,res){
        try{
            let data = await DiscussionTopic.increment('votes',
                    {where:{topic_id:req.params.id}
            });

            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Upvoted"
                });
            }
            else{
                
                res.status(400).json({
                    status:"failure",
                    msg:"Error Occured"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async downvote(req,res){
        try{
            let data = await DiscussionTopic.decrement('votes',
                    {where:{topic_id:req.params.id}
            });

            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Downvoted"
                });
            }
            else{
                
                res.status(400).json({
                    status:"failure",
                    msg:"Error Occured"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_topic_comments(req,res){
        try{
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let data = await Comment.findAll({
                offset,limit,
                where:{ topic_id:req.params.id},
                include:[
                {
                    model:User,
                    as:'user',
                    attributes:["user_id","profile_img","first_name","last_name"]
                },
                {
                    model:CommentReply,
                    as:'comment_replies',
                    include:{
                        model:User,
                        as:'user',
                        attributes:["user_id","profile_img","first_name","last_name"]
                    }
                }],
                order:[["createdAt",req.query.order]]
            });

            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }
}

module.exports = new CommunityController();