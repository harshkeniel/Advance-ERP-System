const sequelize = require("sequelize");
const shortid = require("shortid")
const Op = sequelize.Op;
const { User,Classroom,ClassroomSubmission,ClassroomAssignment,ClassroomMember } = require("../models");

class ClassroomController {

    async create_classroom(req,res){
        try{
            req.body.classroom_code = shortid.generate();
            let data = await Classroom.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Classroom Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Classroom Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_classroom(req,res){
        try{
            let data = await Classroom.findOne({
                where:{ classroom_id:req.params.id },
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async edit_classroom(req,res){
        try{
            let data = await Classroom.update(req.body,{
                where:{
                    classroom_id:req.params.id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_classroom(req,res){
        try{
            let data = await Classroom.destroy({
                where:{
                    classroom_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Classroom Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Classroom Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }
    
    async get_all_assignments(req,res){
        try{
            let data = await ClassroomAssignment.findAll({
                where:{classroom_id:req.params.id}
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async create_assignment(req,res){
        try{
            let data = await ClassroomAssignment.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Assignment Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Assignemnt Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_assignment(req,res){
        try{
            let data = await ClassroomAssignment.findOne({
                where:{ assignment_id:req.params.assignment_id },
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }   

    async edit_assignment(req,res){
        try{
            let data = await ClassroomAssignment.update(req.body,{
                where:{
                    assignment_id:req.params.assignment_id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async delete_assignment(req,res){
        try{
            let data = await ClassroomAssignment.destroy({
                where:{
                    assignment_id:req.params.assignment_id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Assignment Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Assignment Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async add_submission(req,res){
        try{
            let data = await ClassroomSubmission.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Submission Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Submission Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_all_submissions(req,res){
        try{
            let data = await ClassroomSubmission.findAll({
                where:{assignment_id:req.params.assignment_id}
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_submission(req,res){
        try{
            let data = await ClassroomSubmission.findOne({
                where:{submission_id:req.params.sub_id}
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async assign_score(req,res){
        try{
            let data = await ClassroomSubmission.update({grade:req.body.grade},{
                where:{submission_id:req.params.sub_id}
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Graded Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Not Graded"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }
}

module.exports = new ClassroomController();