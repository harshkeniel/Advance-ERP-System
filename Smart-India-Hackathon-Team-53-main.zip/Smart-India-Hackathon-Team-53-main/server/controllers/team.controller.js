const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User,Team,TeamActivity,TeamMember } = require("../models");

class TeamController {

    async create_team(req,res){
        try{
            let new_team = await Team.create(req.body);

            let add_member = await TeamMember.create({
                team_member_id:new_team.team_id
            });

            if(new_team && add_member){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Team Not Created"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async add_member(req,res){
        try{
            let member_exist = await TeamMembers.findOne({
                where:{
                    team_id:req.body.team_id,
                    team_member_id:req.body.team_member_id
                }
            });
            if(member_exist){
                return res.status(400).json({
                    status:"failure",
                    msg:"Member already added in team"
                });
            }
            let data = await TeamMembers.create(req.body);
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Team Member Not Added"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async remove_member(req,res){
        try{
            let member_exist = await TeamMembers.findOne({
                where:{
                    team_id:req.params.id,
                    team_member_id:req.params.member_id
                }
            })

            if(!member_exist){
                return res.status(404).json({
                    status:"failure",
                    msg:"Member Not Found in the team"
                });
            }
            let data = await TeamMembers.destroy({
                where:{team_member_id:req.params.member_id}
            });

            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Member Removed Successfully"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Failed to added member"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async get_single_team(req,res){
        try{
            let data = await Team.findOne({
                where:{team_id:req.params.id},
                include:{
                    model:TeamMembers
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"No Team Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    } 

    async get_all_team_members(req,res){
        try{
            let data = await TeamMembers.findAll({
                where:{team_id:req.params.id}
            });
            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"No Members Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }
}

module.exports = new TeamController();