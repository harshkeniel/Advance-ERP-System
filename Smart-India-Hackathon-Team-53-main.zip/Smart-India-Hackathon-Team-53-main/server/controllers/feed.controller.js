const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User, Follower, College, DomainBoard, Post, UserDomainMapping, Project,
    Team, TeamMembers, SavedPost ,PostClap,SimilarProject} = require("../models");

class FeedController {

    async get_user_feed(req, res) {
        try {
            // Pagination
            // let primeUser = "";
           // console.log(req.user.id)
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let clapped_posts = await PostClap.findAll({
                where:{user_id:req.user.id},
                include:{
                    model:Post,
                    as:'post',
                    attributes:["post_id"],
                    include:{
                        model:Project,
                        as:'project',
                        attributes:["project_id"]
                    }
                },
                raw:true
            });

            let similar = await SimilarProject.findAll({
                where:{
                    [Op.or]: [
                        { project_id: clapped_posts.map((proj) => proj["post.project.project_id"]) }
                    ]
                },
                attributes:["similar_projects"],
                raw:true
            });
           // console.log(similar)
            let similar_data = await Project.findAll({
                where:{
                    [Op.or] :[
                        {project_id:similar.map((s,idx) => s['similar_projects'][idx])}
                    ]
                },
                attributes:["project_id"],
                raw:true
            });

            let following_users = await Follower.findAll({
                where: { followed_by_id: req.user.id },
                attributes: ["following_id"],
                order: [["createdAt", "DESC"]],
                raw: true
            });

            let following_users_projects = await TeamMembers.findAll({
                where: {
                    [Op.or]: [
                        { team_member_id: following_users.map((member) => member.following_id) }
                    ]
                },
                include: {
                    model: Team,
                    as: 'team',
                    attributes: ["team_id"],
                    include: {
                        model: Project,
                        as: 'project',
                        attributes: ["project_id"]
                    }
                },
                raw: true
            });

            let following_domains = await UserDomainMapping.findAll({
                where: {
                    user_id: req.user.id
                },
                attributes: ["domain_id"],
                raw: true
            });

            let following_domain_projects = await Post.findAll({
                where: {
                    [Op.or]: [
                        { board_id: following_domains.map((domain) => domain.domain_id) }
                    ]
                },
                attributes: ["project_id"],
                raw: true
            });

            let all_posts = following_users_projects.concat(following_domain_projects,similar_data);
            let data = await Post.findAll({
                where: {
                    [Op.or]: [
                        { project_id: all_posts.map((post) => post["team.project.project_id"]) }
                    ]
                },
                attributes: {
                    include: [
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_clapped"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_saved"]
                    ]
                },
                include: {
                    model: DomainBoard,
                    as: 'domain_board'
                },
                include: {
                    model: User,
                    as: 'user',
                    attributes: ["user_id", "first_name", "last_name", "profile_img"]
                },
                include: {
                    model: Project,
                    as: 'project',
                    attributes:["project_id","name","tech_stack"],
                    include: [
                        {
                            model: Team,
                            as: 'project_team',
                            include: {
                                model: TeamMembers,
                                as: 'team_members',
                                    include: {
                                        model: User,
                                        as: 'user',
                                        attributes:["user_id","first_name","last_name","profile_img"]
                                }
                            },
                            include: {
                                model: User,
                                as: 'user',
                                attributes:["user_id","first_name","last_name","profile_img"]

                            }
                        }
                    ]
                }
            });

            res.status(200).json({
                status: "success",
                data: data
            });

        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_college_feed(req, res) {
        try {
            let data = await Post.findAll({
                attributes: {
                    include: [
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_saved"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_clapped"]
                    ]
                },
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ["user_id", "first_name", "last_name", "profile_img"],
                        where: { college_id: req.query.id }
                    },
                    {
                        model: DomainBoard,
                        as: 'domain_board'
                    }
                ]
            });

            data = JSON.stringify(data);
            data = JSON.parse(data);

            let now = new Date();
            for (let i = 0; i < data.length; i++) {
                let created = new Date(data[i].createdAt)
                let time_delta = (now - created)
                data[i].score = parseInt(data[i].claps) / time_delta
            }

            data.sort((a, b) => {
                return b.score - a.score
            });

            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "Data Not Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }

    async get_trending_posts(req, res) {
        try {
            let data = await Post.findAll({
                attributes: {
                    include: [
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_saved"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_clapped"]
                    ]

                },
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ["user_id", "first_name", "last_name", "profile_img"]
                    },
                    {
                        model: DomainBoard,
                        as: 'domain_board'
                    }
                ]
            });
            data = JSON.stringify(data)
            data = JSON.parse(data)
            if (data.length === 0) {
                return res.status(404).json({
                    status: "failure",
                    msg: "Data Not Found"
                });
            }
            let now = new Date();
            for (let i = 0; i < data.length; i++) {
                let created = new Date(data[i].createdAt)
                let timeDelta = (now - created)
                data[i].score = parseInt(data[i].claps_count) / timeDelta
            }
            //console.log(data)
            data.sort((a, b) => {
                return b.score - a.score
            });

            res.status(200).json({
                status: "success",
                data: data
            });
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }

    }

    async get_feed_by_domain(req, res) {
        try {
            let data = await Post.findAll({
                where: { board_id: req.query.id },
                attributes: {
                    include: [
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_saved"],
                        [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_clapped"]
                    ]

                },
                include: [
                    {
                        model: DomainBoard,
                        as: 'domain_board',
                        attributes: {
                            exclude: ["createdAt", "updatedAt"]
                        }
                    },
                    {
                        model: User,
                        as: 'user',
                        attributes: ["user_id", "first_name", "last_name", "profile_img"]
                    }
                ]
            });
            if (data.length != 0) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "Data Not Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }
}

module.exports = new FeedController();