const sequelize = require("sequelize");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Op = sequelize.Op;
const { Faculty } = require("../models");

class FacultyController {

    async login(req, res) {
        try {
            let { email, password } = req.body;
            const faculty_exists = await Faculty.findOne({
                where: { email }
            });
            if (faculty_exists) {
                const is_match = await bcrypt.compare(password, faculty_exists.password);
                if (is_match) {
                    const token = await jwt.sign({ id: faculty_exists.faculty_id,role:'faculty' }, process.env.JWT_SECRET_SIGNATURE);
                    res.status(200).json({
                        status: "success",
                        msg: "Login Successful",
                        token: token
                    });
                }
                else {
                    res.status(401).json({
                        status: "failure",
                        msg: "email or password wrong"
                    });
                }
            }
            else {
                res.status(401).json({
                    status: "failure",
                    msg: "Faculty does not exists"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err
            });
        }
    }

    async signup(req, res) {
        try {
            req.body.password = await bcrypt.hash(req.body.password, 10)
            let data = await Faculty.create(req.body);
            if (data) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(400).json({
                    status: "failure",
                    msg: "Signup Unsuccessful"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                error: err
            });
        }
    }

    async get_profile(req, res) {
        try {
            let data = await Faculty.findOne({
                where: {
                    faculty_id: req.params.id
                }
            });
            if (data) {
                res.status(200).json({
                    status: "success",
                    data: data
                });
            }
            else {
                res.status(404).json({
                    status: "failure",
                    msg: "No data Found"
                });
            }
        }
        catch (err) {
            console.log(err);
            res.status(500).json({
                status: "failure",
                msg: err.message
            });
        }
    }
}

module.exports = new FacultyController();