const sequelize = require("sequelize");
const Op = sequelize.Op;
const { User,Post,Project,PostClap,Comment,CommentReply,Team,TeamMembers,SavedPost,
DomainBoard } = require("../models");

class PostController {

    async create_post(req,res){
        try{
            let project_data = await Project.findOne({
                where:{project_id:req.body.project_id}
            });
            if(!project_data){
                return res.status(404).json({
                    status:"failure",
                    msg:"Project Not Found"
                });
            }
            let new_post = {
                project_id:project_data.project_id,
                user_id:project_data.user_id,
                title:project_data.name,
                description:project_data.idea_description
            };
            let data = await Post.create(new_post);
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Post Created Successfully",
                    data:data
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Post Not Created"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async update_post(req,res){
        try{
            let data = await Post.update(req.body,{
                where:{
                    post_id:req.params.id
                }
            });
            if(data[0]){
                res.status(200).json({
                    status:"success",
                    msg:"Update SuccessFul"
                });
            }
            else{
                res.status(400).json({
                    status:"failure",
                    msg:"Update Failed"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }
    
    async delete_post(req,res){
        try{
            let data = await Post.destroy({
                where:{
                    post_id:req.params.id
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    msg:"Post Deleted SuccessFully"
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_post(req,res){
        try{
            let data;
            if(req.user){
                data = await Post.findOne({
                    where:{ post_id:req.params.id },
                    attributes: {
                        include: [
                            [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps"],
                            [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"],
                            [sequelize.literal(`(SELECT COUNT(*) FROM saved_posts WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_saved"],
                            [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id" AND user_id = '${req.user.id}')`), "is_clapped"]
                        ]
                    },
                    include:[
                        {
                            model:DomainBoard,
                            as:'domain_board'
                        },
                        {
                            model:User,
                            as:'user'
                        }
                    ]
                });
            }
            else{
                data = await Post.findOne({
                    where:{ post_id:req.params.id },
                    attributes: {
                        include: [
                            [sequelize.literal(`(SELECT COUNT(*) FROM post_claps WHERE post_id = "Post"."post_id")`), "claps"],
                            [sequelize.literal(`(SELECT COUNT(*) FROM comments WHERE post_id = "Post"."post_id")`), "comments_count"]
                        ]
                    },
                    include:[
                        {
                            model:DomainBoard,
                            as:'domain_board'
                        },
                        {
                            model:User,
                            as:'user'
                        }
                    ]
                });
            }
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_post_info(req,res){
        try{
            let data = await Post.findOne({
                where:{ post_id:req.params.id },
                include:{
                    model:Project,
                    as:'project',
                    attributes:["project_id","name","idea_description","tags","tech_stack"],
                    include:{
                        model:Team,
                        as:'project_team',
                        include:{
                            model:TeamMembers,
                            as:'team_members',
                            include:{
                                model:User,
                                as:'user',
                                attributes:["user_id","profile_img","first_name","last_name"]
                            }
                        }
                    }
                }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_claps(req,res){
        try{
            let data = await Post.findOne({
                where:{ post_id:req.params.id },
                include:{
                    model:PostClap,
                    as:'post_claps',
                    attributes:['user_id']
                }
                // attributes:{
                //     include:[[sequelize.literal(`(SELECT COUNT(*) FROM post_claps where post_id=posts.post_id)`),"cnt"]]
                // }
            });
            if(data){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data not Found"
                });
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }

    async handle_clap_unclap(req,res){
        try{
            let clapped = await PostClap.findOne({
                where:{
                    user_id:req.user.id,
                    post_id:req.params.id
                }
            })
            if(clapped){
                let data = await PostClap.destroy({
                    where:{
                        user_id:req.user.id,
                        post_id:req.params.id
                    }
                }); 
                if(data){
                    res.status(200).json({
                        status:"success",
                        msg:"Post Unclapped",
                        data:data
                    });
                }
                else{
                    res.status(404).json({
                        status:"failure",
                        msg:"Data not Found"
                    });
                }
            }
            else{
                let data = await PostClap.create({
                    user_id:req.user.id,
                    post_id:req.params.id
                });
                if(data){
                    res.status(200).json({
                        status:"success",
                        msg:"Post Clap Success",
                        data:data
                    });
                }
                else{
                    res.status(400).json({
                        status:"failure",
                        msg:"failed"
                    });
                }
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    // async handle_unclap(req,res){
    //     try{
    //         let clapped = await PostClap.findOne({
    //             where:{
    //                 user_id:req.user.id,
    //                 post_id:req.params.id
    //             }
    //         })
    //         if(!clapped){
    //             return res.status(400).json({
    //                 status:"failure",
    //                 msg:"Function Not Allowed"
    //             })
    //         }
    //         let data = await PostClap.destroy({
    //             where:{
    //                 user_id:req.user.id,
    //                 post_id:req.params.id
    //             }
    //         });
    //         if(data){
    //             res.status(200).json({
    //                 status:"success",
    //                 data:data
    //             });
    //         }
    //         else{
    //             res.status(404).json({
    //                 status:"failure",
    //                 msg:"Data not Found"
    //             });
    //         }
    //     }
    //     catch(err){
    //         console.log(err);
    //         res.status(500).json({
    //             status:"failure",
    //             error:err.message
    //         });
    //     }
    // } 

    async handle_save_unsave(req,res){
        try{
            let saved = await SavedPost.findOne({
                where:{
                    user_id:req.user.id,
                    post_id:req.params.id
                }
            });
            if(saved){
                let data = await SavedPost.destroy({
                    where:{
                        user_id:req.user.id,
                        post_id:req.params.id
                    }
                });
                if(data){
                    res.status(200).json({
                        status:"success",
                        msg:"Post unsaved"
                    });
                }
                else{
                    res.status(404).json({
                        status:"failure",
                        msg:"Data not Found"
                    });
                }
            }
            else{
             let data = await SavedPost.create({
                    user_id:req.user.id,
                    post_id:req.params.id
                });
                if(data){
                    res.status(200).json({
                        status:"success",
                        msg:"post unsaved",
                        data:data
                    });
                }
                else{
                    res.status(400).json({
                        status:"failure",
                        msg:"failed"
                    });
                }
            }
        }
        catch(err){
            console.log(err);
            res.status(500).json({
                status:"failure",
                error:err.message
            });
        }
    }

    async get_post_comments(req,res){
        try{
            var offset = req.query.page;
            var limit = req.query.limit;
            if (!offset || offset < 1) {
                offset = 0;
            } else {
                offset = (offset - 1) * limit;
            }
            let data = await Comment.findAll({
                offset,limit,
                where:{post_id:req.params.id},
                attributes:{
                    exclude:["topic_id"]
                },
                include:[
                {
                    model:User,
                    as:'user',
                    attributes:["user_id","profile_img","first_name","last_name"]
                },
                {
                    model:CommentReply,
                    as:'comment_replies',
                    include:{
                        model:User,
                        as:'user',
                        attributes:["user_id","profile_img","first_name","last_name"]
                    }
                }],
                order:[["createdAt",req.query.order]]
            });

            if(data.length != 0){
                res.status(200).json({
                    status:"success",
                    data:data
                });
            }
            else{
                res.status(404).json({
                    status:"failure",
                    msg:"Data Not Found"
                });
            }
        }
        catch(err){
            console.log(err)
            res.status(500).json({
                status:"failure",
                msg:err.message
            });
        }
    }
}

module.exports = new PostController();