'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserEducation extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  UserEducation.init({
    education_id:{
      allowNull:false,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      type:DataTypes.UUID
    },
    university_name:{
      allowNull:true,
      type:DataTypes.STRING
    },
    study_field:{
      allowNull:true,
      type:DataTypes.STRING
    },
    degree:{
      allowNull:true,
      type:DataTypes.STRING
    },
    grade:{
      type:DataTypes.FLOAT,
      allowNull:true
    },
    start_year:{
      type:DataTypes.DATEONLY
    },
    end_year:{
      type:DataTypes.DATEONLY
    }
  }, {
    sequelize,
    tableName:'user_educations',
    modelName: 'UserEducation',
  });
  return UserEducation;
};

