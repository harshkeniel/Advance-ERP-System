'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Comments extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.hasMany(models.CommentReply,{as:'comment_replies',foreignKey:'comment_id'});
      this.belongsTo(models.Post,{foreignKey:'post_id'});
      this.belongsTo(models.DiscussionTopic,{as:'discussion_topic',foreignKey:'topic_id'});
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  
  Comments.init({
    comment_id:{
      primaryKey:true,
      allowNull:false,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4
    },
    type:{
      allowNull:false,
      type:DataTypes.STRING
    },
    post_id:{
      allowNull:true,
      type:DataTypes.UUID
    },
    topic_id:{
      allowNull:true,
      type:DataTypes.UUID
    },
    user_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    comment_description:{
      allowNull:false,
      type:DataTypes.STRING(1000)
    },
    votes:{
      type:DataTypes.INTEGER,
      defaultValue:0
    }
  }, {
    sequelize,
    tableName:'comments',
    modelName: 'Comment',
  });
  return Comments;
};