'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserCertification extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  UserCertification.init({
    certification_id:{
      allowNull:false,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      type:DataTypes.UUID
    },
    title:{
      allowNull:false,
      type:DataTypes.STRING
    },
    skills:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    description:{
      allowNull:true,
      type:DataTypes.STRING(1000)
    },
    issue_date:{
      type:DataTypes.DATEONLY,
      allowNull:true
    },
    link:{
      type:DataTypes.STRING
    }

  }, {
    sequelize,
    tableName:'user_certifications',
    modelName: 'UserCertification',
  });
  return UserCertification;
};