'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Team extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Project,{as:'project',foreignKey:'project_id'});
      this.hasMany(models.TeamMembers,{as:'team_members',foreignKey:'team_id'});
      this.belongsTo(models.User,{as:'user',foreignKey:'leader_id'});
      this.hasMany(models.ClassroomMember,{as:'classroom_members',foreignKey:'team_id'});
    }
  }
  Team.init({
    team_id:{
      type:DataTypes.UUID,
      allowNull:false,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4
    },
    leader_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    project_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    team_name:{
      type:DataTypes.STRING,
      allowNull:true
    }
  }, {
    sequelize,
    tableName:'teams',
    modelName: 'Team',
  });
  return Team;
};