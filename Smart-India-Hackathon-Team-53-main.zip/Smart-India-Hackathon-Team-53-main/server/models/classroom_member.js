'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ClassroomMember extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Classroom,{as:'classroom',foreignKey:'classroom_id'});
      this.belongsTo(models.Team,{as:'team',foreignKey:'team_id'});
    }
  }
  ClassroomMember.init({
    team_id:{
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID
    },
    classroom_id:{
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID
    }
  }, {
    sequelize,
    tableName:'classroom_members',
    modelName: 'ClassroomMember',
  });
  return ClassroomMember;
};