'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Follower extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // this.belongsTo(models.User,{foreignKey:'following_id'})
      // this.belongsTo(models.User,{foreignKey:'followed_by_id'})
    }
  }
  Follower.init({
     following_id:{
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID
     },
     followed_by_id:{
        allowNull:false,
        primaryKey:true,
        type:DataTypes.UUID
     }
  }, {
    sequelize,
    tableName:'followers',
    modelName: 'Follower',
  });
  return Follower;
};