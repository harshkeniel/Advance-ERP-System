'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Post extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
      this.belongsTo(models.Project,{as:'project',foreignKey:'project_id'});
      this.hasMany(models.PostClap,{as:'post_claps',foreignKey:'post_id'});
      this.hasMany(models.Comment,{as:'post_comments',foreignKey:'post_id'});
      this.belongsTo(models.DomainBoard,{as:'domain_board',foreignKey:'board_id'});
      this.hasMany(models.SavedPost,{as:'saved_posts',foreignKey:'post_id'});

    }
  }
  Post.init({
    post_id:{
      type:DataTypes.UUID,
      primaryKey:true,
      allowNull:false,
      defaultValue:DataTypes.UUIDV4
    },
    project_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    user_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    title:{
      allowNull:false,
      type:DataTypes.STRING
    },
    description:{
      allowNull:false,
      type:DataTypes.STRING(2000)
    },
    post_image:{
      allowNull:true,
      type:DataTypes.STRING
    },
    board_id:{
      allowNull:false,
      type:DataTypes.UUID
    }
  }, {
    sequelize,
    tableName:'posts',
    modelName: 'Post',
  });
  return Post;
};