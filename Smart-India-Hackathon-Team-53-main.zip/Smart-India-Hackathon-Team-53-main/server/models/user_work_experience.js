'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserWorkExperience extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  UserWorkExperience.init({
    experience_id:{
      allowNull:false,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      type:DataTypes.UUID
    },
    company_name:{
      allowNull:true,
      type:DataTypes.STRING
    },
    internship_type:{
      allowNull:true,
      type:DataTypes.STRING
    },
    company_link:{
      allowNull:true,
      type:DataTypes.STRING
    },
    internship_title:{
      type:DataTypes.STRING,
      allowNull:true
    },
    company_location:{
      type:DataTypes.STRING
    },
    start_year:{
      type:DataTypes.DATEONLY
    },
    end_year:{
      type:DataTypes.DATEONLY
    },
    description:{
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    skills:{
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    certificate_link:{
      type:DataTypes.STRING
    }
  }, {
    sequelize,
    tableName:'user_work_experiences',
    modelName: 'UserWorkExperience',
  });
  return UserWorkExperience;
};