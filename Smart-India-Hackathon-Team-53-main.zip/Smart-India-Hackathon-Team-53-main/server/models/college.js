'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class College extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.hasOne(models.CollegeAdmin,{foreignKey:'college_id'});
      this.hasMany(models.Faculty,{as:'faculties',foreignKey:'college_id'});
      this.hasMany(models.User,{as:'users',foreignKey:'college_id'});
    }
  }
  College.init({
    college_id: {
      allowNull:false,
      type:DataTypes.UUID,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4
    },
    college_name:{
      allowNull:false,
      type:DataTypes.STRING
    },
    university_name:{
      allowNull:true,
      type:DataTypes.STRING
    },
    college_logo:{
      allowNull : true,
      type : DataTypes.STRING
    },
    college_banner:{
      allowNull : true,
      type : DataTypes.STRING
    },
    college_code:{
      allowNull:true,
      type:DataTypes.STRING
    },
    state:{
      allowNull:true,
      type:DataTypes.STRING
    },
    city:{
      allowNull:true,
      type:DataTypes.STRING
    },
    pinned_projects:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.UUID)
    },
    pinned_students:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.UUID)
    }
  }, {
    sequelize,
    tableName:'colleges',
    modelName: 'College',
  });
  return College;
};