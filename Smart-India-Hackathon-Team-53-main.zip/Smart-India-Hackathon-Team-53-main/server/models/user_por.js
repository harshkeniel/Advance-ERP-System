'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserPOR extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  UserPOR.init({
    por_id:{
      allowNull:false,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      type:DataTypes.UUID
    },
    title:{
      allowNull:true,
      type:DataTypes.STRING
    },
    skills:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    position:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    start:{
      type:DataTypes.DATEONLY
    },
    end:{
      type:DataTypes.DATEONLY
    }
  }, {
    sequelize,
    tableName:'user_pors',
    modelName: 'UserPOR',
  });
  return UserPOR;
};