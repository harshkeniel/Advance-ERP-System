'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class DiscussionTopic extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.hasMany(models.Comment,{as:'discussion_comments',foreignKey:'topic_id'})
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'})
    }
  }
  DiscussionTopic.init({
    topic_id:{
      primaryKey:true,
      allowNull:false,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4
    },
    user_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    title:{
      type:DataTypes.STRING,
      allowNull:false
    },
    description:{
      type:DataTypes.STRING(5000),
      allowNull:false
    },
    tech_stack:{
      type:DataTypes.ARRAY(DataTypes.STRING),
      allowNull:true
    },
    tags:{
      type:DataTypes.ARRAY(DataTypes.STRING),
      allowNull:true
    },
    domain:{
      type:DataTypes.ARRAY(DataTypes.UUID),
      allowNull:true
    },
    votes:{
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    likes:{
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    views:{
      type:DataTypes.INTEGER,
      defaultValue:0
    }
  }, {
    sequelize,
    tableName:'discussion_topics',
    modelName: 'DiscussionTopic',
  });
  return DiscussionTopic;
};