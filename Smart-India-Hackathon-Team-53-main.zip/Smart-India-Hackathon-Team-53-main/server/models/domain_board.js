'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Domain_Board extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.hasMany(models.UserDomainMapping,{as:'users',foreignKey:'domain_id'});
      this.hasMany(models.DomainBoard,{as:'projects',foreignKey:'board_id'});
      this.hasMany(models.Post,{as:'posts',foreignKey:'board_id'});
    }
  }
  Domain_Board.init({
    board_id:{
      type:DataTypes.UUID,
      allowNull:false,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4
    },
    board_name:{
      type:DataTypes.STRING,
      allowNull:false
    },
    board_color:{
      type:DataTypes.STRING,
      allowNull:false
    }
  }, {
    sequelize,
    tableName:'domain_boards',
    modelName: 'DomainBoard',
  });
  return Domain_Board;
};