'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Classroom extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.hasMany(models.ClassroomMember,{as:'classroom_members',foreignKey:'classroom_id'});
      this.hasMany(models.ClassroomAssignment,{as:'classroom_assignments',foreignKey:'classroom_id'});
    }
  }
  Classroom.init({
    classroom_id:{
      allowNull:false,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4,
      type:DataTypes.UUID
    },
    faculty_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    classroom_name:{
      type:DataTypes.STRING,
      allowNull:false
    },
    classroom_code:{
      type:DataTypes.STRING,
      allowNull:false,
      unique:true
    }
  }, {
    sequelize,
    tableName:'classrooms',
    modelName: 'Classroom',
  });
  return Classroom;
};