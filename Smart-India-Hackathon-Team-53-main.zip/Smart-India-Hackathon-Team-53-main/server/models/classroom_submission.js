'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ClassroomSubmission extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.ClassroomAssignment,{as:'classroom_assignment',foreignKey:'assignment_id'});
    }
  }
  ClassroomSubmission.init({
    submission_id:{
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4,
      allowNull:false,
      primaryKey:true
    },
    assignment_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    team_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    status:{
      type:DataTypes.STRING,
      defaultValue:'pending'
    },
    files:{
      type:DataTypes.ARRAY(DataTypes.STRING),
      allowNull:true
    },
    grade:{
      type:DataTypes.INTEGER,
      allowNull:true
    }
  }, {
    sequelize,
    tableName:'classroom_submissions',
    modelName: 'ClassroomSubmission',
  });
  return ClassroomSubmission;
};