'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ProjectTask extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.ProjectTask,{as:'project',foreignKey:'project_id'});
      this.belongsTo(models.User,{as:'user',foreignKey:'assigned_to'});
    }
  }
  ProjectTask.init({
    task_id:{
      type:DataTypes.UUID,
      allowNull:false,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4
    },
    project_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    assigned_to:{
      type:DataTypes.UUID,
      allowNull:false
    },
    name:{
      type:DataTypes.STRING,
      allowNull:false
    },
    description:{
      type:DataTypes.STRING,
      allowNull:true
    },
    status:{
      type:DataTypes.STRING,
      defaultValue:'To-do'
    }
  }, {
    sequelize,
    tableName:'project_tasks',
    modelName: 'ProjectTask',
  });
  return ProjectTask;
};