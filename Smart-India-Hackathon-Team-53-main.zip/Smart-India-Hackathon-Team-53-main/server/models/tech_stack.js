'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TechStack extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  TechStack.init({
    tech_stack_id:{
      allowNull:false,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true
    },
    title:{
      allowNull:false,
      type:DataTypes.STRING,
      unique:true
    }
  }, {
    sequelize,
    tableName:'tech_stacks',
    modelName: 'TechStack',
  });
  return TechStack;
};