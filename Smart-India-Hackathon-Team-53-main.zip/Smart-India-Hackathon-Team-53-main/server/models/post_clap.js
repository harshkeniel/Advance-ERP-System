'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PostClap extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Post,{as:'post',foreignKey:'post_id'})
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'})
      
    }
  }
  PostClap.init({
    post_id:{
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID
    },
    user_id:{
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID
    }
  }, {
    sequelize,
    tableName:'post_claps',
    modelName: 'PostClap',
  });
  return PostClap;
};