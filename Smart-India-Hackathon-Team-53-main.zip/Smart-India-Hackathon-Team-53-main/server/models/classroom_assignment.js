'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ClassroomAssignment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Classroom,{as:'classroom',foreignKey:'classroom_id'});
      this.hasMany(models.ClassroomSubmission,{as:'classroom_submissions',foreignKey:'assignment_id'});
    }
  }
  ClassroomAssignment.init({
    assignment_id:{
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4
    },
    classroom_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    title:{
      allowNull:false,
      type:DataTypes.STRING
    },
    description:{
      allowNull:true,
      type:DataTypes.STRING(1000)
    },
    files:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    due_date:{
      allowNull:true,
      type:DataTypes.DATE
    }
  }, {
    sequelize,
    tableName:'classroom_assignments',
    modelName: 'ClassroomAssignment',
  });
  return ClassroomAssignment;
};