'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ProjectStory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Project,{as:'project',foreignKey:'project_id'});
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  ProjectStory.init({
    story_id:{
      primaryKey:true,
      allowNull:false,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4
    },
    project_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    user_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    story_text:{
      allowNull:false,
      type:DataTypes.STRING(1000)
    },
    story_type:{
      allowNull:false,
      type:DataTypes.STRING
    }
  }, {
    sequelize,
    tableName:'project_stories',
    modelName: 'ProjectStory',
  });
  return ProjectStory;
};