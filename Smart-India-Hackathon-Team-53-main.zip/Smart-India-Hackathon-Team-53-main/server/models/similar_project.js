'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class SimilarProject extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Project,{as:'project',foreignKey:'project_id'});
    }
  }
  SimilarProject.init({
    project_id:{
      primaryKey:true,
      allowNull:false,
      type:DataTypes.UUID
    },
    similar_projects:{
      primaryKey:true,
      allowNull:false,
      type:DataTypes.ARRAY(DataTypes.UUID)
    }
  }, {
    sequelize,
    timestamps:false,
    tableName:'similar_projects',
    modelName: 'SimilarProject',
  });
  return SimilarProject;
};