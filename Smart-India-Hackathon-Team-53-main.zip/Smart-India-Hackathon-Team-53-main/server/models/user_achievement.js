'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserAchievement extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
    }
  }
  UserAchievement.init({
    achievement_id:{
      allowNull:false,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      type:DataTypes.UUID
    },
    title:{
      allowNull:false,
      type:DataTypes.STRING
    },
    issuer:{
      allowNull:true,
      type:DataTypes.STRING
    },
    issue_date:{
      type:DataTypes.DATEONLY
    },
    description:{
      type:DataTypes.STRING(1000)
    }

  }, {
    sequelize,
    tableName:'user_achievements',
    modelName: 'UserAchievement',
  });
  return UserAchievement;
};