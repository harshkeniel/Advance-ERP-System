'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TeamMembers extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Team,{as:'team',foreignKey:'team_id'});
      this.belongsTo(models.User,{as:'user',foreignKey:'team_member_id'})
      
    }
  }
  TeamMembers.init({
    team_member_id:{
       type:DataTypes.UUID,
       primaryKey:true,
       allowNull:false
    },
    team_id:{
      allowNull:false,
      type:DataTypes.UUID,
      primaryKey:true
    }
  }, {
    sequelize,
    tableName:'team_members',
    modelName: 'TeamMembers',
  });
  return TeamMembers;
};