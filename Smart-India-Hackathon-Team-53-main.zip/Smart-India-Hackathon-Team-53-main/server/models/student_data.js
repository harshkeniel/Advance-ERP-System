'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class StudentData extends Model {

    static associate(models) {
      
    }

    toJSON(){
      return {...this.get(),password:undefined}
    }
  }
 StudentData.init({
    college_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    student_email:{
      allowNull:false,
      type:DataTypes.STRING
    },
    student_first_name:{
        allowNull:false,
        type:DataTypes.STRING
    },
    student_last_name:{
        allowNull:false,
        type:DataTypes.STRING
    }
  }, {
    sequelize,
    tableName:'student_data',
    modelName: 'StudentData',
  });
  return StudentData;
};