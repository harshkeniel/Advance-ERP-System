'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ProjectMedia extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Project,{as:'project',foreignKey:'project_id'})
      
    }
  }
  ProjectMedia.init({
    media_id:{
      allowNull:false,
      primaryKey:true,
      defaultValue:DataTypes.UUIDV4,
      type:DataTypes.UUID
    },
    project_id:{
      allowNull:false,
      type:DataTypes.UUID
    },
    media_url:{
      type:DataTypes.STRING,
      allowNull:false
    },
    file_name:{
      type:DataTypes.STRING,
      allowNull:false
    },
    file_type:{
      type:DataTypes.STRING,
      allowNull:false
    }
  }, {
    sequelize,
    tableName:'project_media',
    modelName: 'ProjectMedia',
  });
  return ProjectMedia;
};