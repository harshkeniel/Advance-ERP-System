'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Project extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.User,{foreignKey:'user_id'});
      this.hasOne(models.Team,{as:'project_team',foreignKey:'project_id'});
      this.hasOne(models.Post,{as:'project_post',foreignKey:'project_id'});
      this.belongsTo(models.DomainBoard,{as:'domain',foreignKey:'domain_id'});
      this.hasMany(models.ProjectMedia,{as:'project_media',foreignKey:'project_id'});
      this.hasMany(models.ProjectLink,{as:'project_links',foreignKey:'project_id'});
      this.hasMany(models.ProjectResource,{as:'project_resources',foreignKey:'project_id'});
      this.hasMany(models.ProjectTask,{as:'project_tasks',foreignKey:'project_id'});
      this.hasMany(models.ProjectStory,{as:'project_stories',foreignKey:'project_id'});
      this.hasMany(models.SimilarProject,{as:'similar_projects',foreignKey:'project_id'});
    }
  }
  
  Project.init({
    project_id:{
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4,
      primaryKey:true,
      allowNull:false
    },
    user_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
    name:{
      type:DataTypes.STRING,
      allowNull:false
    },
    tagline:{
      type:DataTypes.STRING(1000),
      allowNull:true
    },
    problem_statement: {
      type:DataTypes.STRING(5000),
      allowNull : true
    },
    idea_description:{
      type : DataTypes.STRING(5000),
      allowNull : true
    },
    board_id:{
      type:DataTypes.UUID,
      allowNull:true
    },
    tags:{
      type:DataTypes.ARRAY(DataTypes.STRING),
      allowNull:true
    },
    tech_stack:{
      type:DataTypes.ARRAY(DataTypes.STRING),
      allowNull:true
    },
    visibility:{
      type:DataTypes.STRING,
      defaultValue:'private'
    },
    visits:{
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    team_id:{
      type:DataTypes.UUID,
      allowNull:false
    },
  }, {
    sequelize,
    tableName:'projects',
    modelName: 'Project',
  });
  return Project;
};