'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsToMany(models.User,{ 
        as:'followers',
        through:models.Follower,
        foreignKey:'following_id',
        otherKey:'followed_by_id'
      });
      this.belongsToMany(models.User,{ 
        as:'following',
        through:models.Follower,
        foreignKey:'followed_by_id',
        otherKey:'following_id'
      });

      this.hasMany(models.UserAchievement,{as:'achievements',foreignKey:'user_id'});
      this.hasMany(models.UserCertification,{as:'certifications',foreignKey:'user_id'});
      this.hasMany(models.UserEducation,{as:'educations',foreignKey:'user_id'});
      this.hasMany(models.UserWorkExperience,{as:'experiences',foreignKey:'user_id'});
      this.hasMany(models.UserPOR,{as:'pors',foreignKey:'user_id'});
      this.hasMany(models.Project,{as:'projects',foreignKey:'user_id'});
      this.hasMany(models.Post,{as:'posts',foreignKey:'user_id'});
      this.hasMany(models.PostClap,{foreignKey:'user_id'});
      this.hasMany(models.Comment,{as:'comments',foreignKey:'user_id'});
      this.hasMany(models.CommentReply,{as:'comment_replies',foreignKey:'user_id'});
      this.hasMany(models.Team,{as:'team',foreignKey:'leader_id'});
      this.hasMany(models.TeamMembers,{as:'team_members',foreignKey:'team_member_id'});
      this.hasMany(models.DiscussionTopic,{as:'discussion_topics',foreignKey:'user_id'});
      this.hasMany(models.ProjectTask,{as:'project_tasks',foreignKey:'assigned_to'});
      this.hasMany(models.ProjectStory,{as:'project_stories',foreignKey:'user_id'});
      this.belongsTo(models.College,{as:'college',foreignKey:'college_id'});
      this.hasMany(models.UserDomainMapping,{as:'followed_domains',foreignKey:'user_id'});
      this.hasMany(models.SavedPost,{as:'post',foreignKey:'user_id'});
    }

    toJSON(){
      return {...this.get(),password:undefined}
    }
  }
  User.init({
    user_id: {
      allowNull:false,
      primaryKey:true,
      type:DataTypes.UUID,
      defaultValue:DataTypes.UUIDV4
    },
    college_id:{
      allowNull:true,
      type:DataTypes.UUID
    },
    first_name:{
      allowNull:false,
      type:DataTypes.STRING
    },
    last_name:{
      allowNull:false,
      type:DataTypes.STRING
    },
    tagline:{
      allowNull:true,
      type:DataTypes.STRING
    },
    email:{
      allowNull:false,
      type:DataTypes.STRING
    },
    password:{
      allowNull:false,
      type:DataTypes.STRING
    },
    date_of_birth:{
      allowNull:true,
      type:DataTypes.DATEONLY
    },
    gender:{
      allowNull:true,
      type:DataTypes.STRING
    },
    profile_img:{
      allowNull:true,
      type:DataTypes.STRING
    },
    state:{
      allowNull:true,
      type:DataTypes.STRING
    },
    city:{
      allowNull:true,
      type:DataTypes.STRING
    },
    contact_no:{
      allowNull:true,
      type:DataTypes.STRING
    },
    graduation_start_date:{
      allowNull:true,
      type:DataTypes.DATEONLY
    },
    graduation_complete_date:{
      allowNull:true,
      type:DataTypes.DATEONLY
    },
    skills:{
      allowNull:true,
      type:DataTypes.ARRAY(DataTypes.STRING)
    },
    last_logged_in:{
      allowNull:true,
      type:DataTypes.DATE
    }
  }, {
    sequelize,
    tableName:'users',
    modelName: 'User',
  });
  return User;
};