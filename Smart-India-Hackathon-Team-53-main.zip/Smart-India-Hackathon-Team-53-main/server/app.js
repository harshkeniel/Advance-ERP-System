// configuring environment variables
require('dotenv').config()

// Importing required libraries
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const spawn = require('child_process').spawn;
const fileUpload = require("express-fileupload");

const { sequelize } = require("./models");
const routing = require('./routes/index');
const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(fileUpload());

//to serve static stuff (uploads)
app.use(express.static("uploads"))

app.use('/api/', routing);


// Test
app.get('/', (req, res) => res.send("Hello"));

// Cron  
//let now = new Date();   
let now = new Date(2050,01,01); 
cron.schedule(`${now.getSeconds() + 2} ${now.getMinutes()} ${now.getHours()} * * *`, async () => {
    console.log('Running a job');
    const process = spawn('python',["./helpers/similar.py"]);
    process.stdout.on('data', (data) => {
        console.log(`data: ${data}`) ;   
    }); 
    // onsole.log(data)
  }, {  
    scheduled: true,
    timezone: "Asia/Kolkata"
  }); 
 
app.listen(process.env.PORT, async () => {
    try {
        await sequelize.sync({alter:true})
        //await sequelize.authenticate();
        console.log("Database connected");
        console.log(`server running on port ${process.env.PORT}`);
    } catch (error) {
        console.log('Unable to connect to the database:', error);
    }
});