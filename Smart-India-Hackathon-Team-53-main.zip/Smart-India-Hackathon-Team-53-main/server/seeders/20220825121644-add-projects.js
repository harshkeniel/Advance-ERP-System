'use strict';

const { projects } = require("../seeder-data/project");

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('projects', projects)
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('projects', null, {});
  }
};
