'use strict';
const { v4 : uuidv4 } = require("uuid");
const { domains } = require("../seeder-data/domain");

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert("domain_boards", domains)
  },

  async down (queryInterface, Sequelize) {
    queryInterface.bulkDelete("domain_boards")
  }
};
