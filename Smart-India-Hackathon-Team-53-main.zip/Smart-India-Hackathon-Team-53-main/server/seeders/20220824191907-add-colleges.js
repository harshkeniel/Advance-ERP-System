'use strict';

const { colleges } = require("../seeder-data/college");

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('colleges', colleges)
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('colleges', null, {});
  }
};
