'use strict';

const { data } = require("../seeder-data/dummyStudentData");

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('student_data', data)
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('student_data', null, {});
  }
};
