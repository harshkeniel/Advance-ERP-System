const { getPrimeCollegeId } = require("./college")

const data = [
    {
        college_id : getPrimeCollegeId(),
        student_first_name : "Vishal",
        student_last_name : "Pandey",
        student_email : "vishalpandey917@gmail.com",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : getPrimeCollegeId(),
        student_first_name : "Rahul",
        student_last_name : "Prajapati",
        student_email : "rahulprajapati@gmail.com",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : getPrimeCollegeId(),
        student_first_name : "Siddhesh",
        student_last_name : "Mane",
        student_email : "siddheshmane025@gmail.com",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : getPrimeCollegeId(),
        student_first_name : "Ninad",
        student_last_name : "Patil",
        student_email : "npradeeppatil2001@gmail.com",
        createdAt : new Date(),
        updatedAt : new Date()
    },

]

module.exports = { data }