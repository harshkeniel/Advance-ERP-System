exports.domains = [{
    board_id: "2f043597-1c01-4f28-a983-74c33260b031",
    board_name : "Computer Vision",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "fe3db60b-cb70-4a71-910f-d6d5ad33bfc7",
    board_name : "Internet of Things",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "d8ebcc35-5711-4424-adc5-6f8d3b00d6cb",
    board_name : "Electric Vehicles",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "dfdcbdab-678d-48be-91d1-cc5be304b705",
    board_name : "Artificial Intelligence",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "6aa1bec1-cb95-48b6-b9b5-62d10a3464d5",
    board_name : "Machine Learning",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "44ec7069-ab77-4ec1-ade5-bc591428168e",
    board_name : "Web Development",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "5e9ec30a-987f-41de-b9c3-1a54d43ce395",
    board_name : "Mobile Development",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "42b589ff-2870-4cf1-a1b1-b682eb814ce9",
    board_name : "Blockchain",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "bb188602-9bbe-4b93-ad95-778b2a13347b",
    board_name : "Robotics",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  },
  {
    board_id: "610a8c11-b2ec-4162-a80b-35c3d4d44576",
    board_name : "Embedded Systems",
    board_color : "#000000",
    createdAt : new Date(),
    updatedAt : new Date()
  }
]

exports.getDomainBoardId = (name) => {
    return domains.filter( (d) => d.board_name === name)[0]
}