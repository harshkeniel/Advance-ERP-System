const { getDomainBoardId } = require("./domain")

const primeProject = {
    project_id : "a9c47f70-14c1-4cde-a0b5-4b99d9c4786b",
    name : "OmniTalk",
    tagline : "An Video Chat App that provides accessible interfaces for people with disabilities.",
    problem_statement : `
    People with disabilities ( Deaf, Blind, Paralysis ) often use non-verbal 
    modes of communication. Also they are unable to use conventional input devices like keyboard and mouse.
    This makes Video Conferencing Apps inaccessible and makes it impossible for them to communicate with their loved ones
    `,
    idea_description : `
    We will add accessible interfaces onto a Video Chat app. Voice based meeting control can help people who
    cannot access mouse / keyboard. Computer Vision Models can be trained for automatic translation of non-verbal languages
    (Sign Language) to Readable Text.
    `,
    tags : ["Accessibility", "For Social Good", "Video Chat"],
    tech_stack : ["WebGazer.js", "TensorFlow.js", "WebRTC", "ReactJS", "NodeJS"],
    visibility : "public",
    visits : 0,
    user_id : "dba3a844-2b62-4d7c-8215-98797d4669df",
    team_id : "6920569b-6c71-49cd-99c1-6b23b3df5257",
    createdAt : new Date(),
    updatedAt : new Date()

}

const projects = [
    primeProject,
    {
        project_id : "886d0bcf-cfdf-4da6-b442-b9da134eea46",
        name : "OmniTalk",
        idea_description : `
        We will add accessible interfaces onto a Video Chat app. Voice based meeting control can help people who
        cannot access mouse / keyboard. Computer Vision Models can be trained for automatic translation of non-verbal languages
        (Sign Language) to Readable Text.
        `,
        tags : ["Accessibility", "For Social Good", "Video Chat"],
        tech_stack : ["WebGazer.js", "TensorFlow.js", "WebRTC", "ReactJS", "NodeJS"],
        visibility : "public",
        visits : 0,
        user_id : "dba3a844-2b62-4d7c-8215-98797d4669df",
        team_id : "8e50a809-bc9d-4e81-99c8-63eb7575ed40",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        project_id : "e365e9ab-f6c2-4883-99b1-a5c2931b6d66",
        name : "Tweet Sentiment Identifier",
        idea_description : `
        When someone is treated unfairly because of their ethnicity, culture, or recent activities,
        this is known as racism or trolling. It can include things like calling them names, withdrawing
        from them, and even denying them access to services or career prospects. The number of online trolls
        and bigots is rapidly increasing. This is because the user's anonymity has increased. They make comments
        and posts on social media accounts because they are confident that they will not be discovered.
        To prevent this and catch them, we designed a model that, when a user's username is entered, checks
        (and can display) his or her prior history, i.e. the types of postings he or has made.
        To prevent this and catch them, we established a model that reveals the person's prior history,
        such as what type of posts he has been posting, what type of posts he has been tagged in, and
        what he has commented on, and we can restrict that user from social media networks based on
        that information.
        `,
        tags : ["Machine Learning", "Sentiment", "Tweet"],
        tech_stack : ["NodeJS", "nltk", "Python",],
        user_id : "dba3a844-2b62-4d7c-8215-98797d4669df",
        team_id : "05f2bf0a-b799-424b-98c5-9f5cbdea4339",

        visibility : "public",
        visits : 0,
        createdAt : new Date(),
        updatedAt : new Date()
    }
]

module.exports = { primeProject, projects}