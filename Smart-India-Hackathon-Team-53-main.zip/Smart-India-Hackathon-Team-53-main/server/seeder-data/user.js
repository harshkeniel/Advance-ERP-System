const { getPrimeCollegeId } = require("./college");

const primeUser = {
    user_id : "f17fa9ec-241f-4fa5-aea8-1059858bfcbf",
    college_id : getPrimeCollegeId(),
    first_name : "Rahul",
    last_name : "Prajapati",
    tagline : "A Passionate and Enthusiastic Individual seeking to explore new areas and work in a dynamic stable organization where I can improve my skills and knowledge in the field of Computer Engineering allowing myself to pursue a rewarding career ahead",
    email : "prajapatirahul1712001@gmail.com",
    password : "",
    date_of_birth : new Date(2001, 0, 17),
    gender : "male",
    profile_img : "/dummy/rahulProfilePhoto.jpg",
    state : "Maharashtra",
    city : "Mumbai",
    contact_no : "7039370568",
    graduation_start_date : new Date(2019, 5, 1),
    graduation_complete_date : new Date(2023, 5, 1),
    skills : ["ReactJS", "NodeJS", "OpenCV" ],
    last_logged_in : new Date(),
    createdAt : new Date(),
    updatedAt : new Date()
}

const users = [
    primeUser,
    {
        user_id : "2dacefeb-0920-4468-92ae-b4b5da807bc1",
        college_id : getPrimeCollegeId(),
        first_name : "Vishal",
        last_name : "Pandey",
        profile_img : "/dummy/vishalProfilePhoto.jpg",
        email : "vishalpandey917@gmail.com",
        password : "",
        last_logged_in : new Date(),
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        user_id : "8c8f3119-ba81-42c6-8b5b-fe396e68d7af",
        college_id : getPrimeCollegeId(),
        first_name : "Harsh",
        last_name : "Mishra",
        profile_img : "/dummy/harshProfilePhoto.jpg",
        email : "harshmishraandheri@gmail.com",
        password : "",
        last_logged_in : new Date(),
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        user_id : "4f8cf28c-1f9a-433a-8bfd-4f0f86f81b8d",
        college_id : getPrimeCollegeId(),
        first_name : "Ninad",
        last_name : "Patil",
        profile_img : "/dummy/ninadProfilePhoto.jpg",
        email : "npradeeppatil2001@gmail.com",
        password : "",
        last_logged_in : new Date(),
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        user_id : "dba3a844-2b62-4d7c-8215-98797d4669df",
        college_id : getPrimeCollegeId(),
        first_name : "Siddhesh",
        last_name : "Mane",
        profile_img : "/dummy/siddheshProfilePhoto.jpg",
        email : "siddheshmane025@gmail.com",
        password : "",
        last_logged_in : new Date(),
        createdAt : new Date(),
        updatedAt : new Date()
    },
]

module.exports = { users, primeUser}