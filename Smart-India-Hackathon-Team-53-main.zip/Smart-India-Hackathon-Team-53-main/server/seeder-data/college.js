const primeCollege = {
    college_id : "4ea323e2-f829-4968-87ae-b530d19aeb2a",
    college_name : "Thakur College of Engineering and Technology",
    college_logo : "dummy/tcet-logo.jpg",
    college_banner : "dummy/tcet-banner.jpg",
    university_name : "Mumbai University",
    createdAt : new Date(),
    updatedAt : new Date()
}

const getPrimeCollegeId = () => primeCollege.college_id

const colleges = [
    primeCollege,
    {
        college_id : "6600dc5a-e91d-451f-a171-30991c1224f1",
        college_name : "Thakur College of Engineering and Technology",
        university_name : "Mumbai University",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : "dbe97791-bac9-4608-b283-b4930902f58d",
        college_name : "IIT - BHU",
        university_name : "Banaras Hindu University",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : "7a0bb652-c98f-4ed7-9839-314aa767f9c6",
        college_name : "Chandigarh Tehcnical Institute",
        university_name : "Chandigarh University",
        createdAt : new Date(),
        updatedAt : new Date()
    },
    {
        college_id : "6352b038-a68e-4ec0-a482-ab960fcf7985",
        college_name : "College of Engineering Pune",
        university_name : "Savitribai Phule Pune University",
        createdAt : new Date(),
        updatedAt : new Date()
    }
]

module.exports = { primeCollege, getPrimeCollegeId, colleges}
